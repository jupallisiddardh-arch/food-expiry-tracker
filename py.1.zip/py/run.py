#!/usr/bin/env python3
"""Food Expiry Tracker - Application Launcher

StudentLife Hack Project #62 | Domain: Food & Agriculture

Usage:
  python run.py             # Launch Interactive Terminal Interface (CLI)
  python run.py --gui       # Launch Graphical User Interface (Tkinter)
  python run.py --summary   # Print executive summary and exit
  python run.py --export    # Export all reports to /exports and exit
  python run.py --seed      # Seed sample dataset into live database and launch
"""

import sys
import argparse
import os

from src.cli import ExpiryTrackerCLI
from src.gui import launch_food_tracker_gui
from src.storage import StorageManager
from src.analytics import generate_executive_summary
from src.exporter import ReportExporter


def seed_sample_data_if_empty(storage: StorageManager):
    """Seed sample pantry dataset if database is empty."""
    items, _ = storage.load_from_json()
    if not items:
        sample_csv = "data/sample_pantry.csv"
        sample_json = "data/sample_pantry.json"
        if os.path.exists(sample_json):
            res = storage.import_bulk_dataset(sample_json)
            if res["valid_imported_items"]:
                storage.save_to_json(res["valid_imported_items"])
                storage.save_to_csv(res["valid_imported_items"])
                print(f"[*] Initialized database with {len(res['valid_imported_items'])} sample pantry records.")
        elif os.path.exists(sample_csv):
            res = storage.import_bulk_dataset(sample_csv)
            if res["valid_imported_items"]:
                storage.save_to_json(res["valid_imported_items"])
                storage.save_to_csv(res["valid_imported_items"])
                print(f"[*] Initialized database with {len(res['valid_imported_items'])} sample pantry records.")


def main():
    parser = argparse.ArgumentParser(
        description="Food Expiry Tracker - Streamline pantry records and prevent food waste."
    )
    parser.add_argument(
        "--gui", action="store_true", help="Launch Tkinter Graphical User Interface"
    )
    parser.add_argument(
        "--summary", action="store_true", help="Print executive analytics summary and exit"
    )
    parser.add_argument(
        "--export", action="store_true", help="Generate all reports (Markdown, CSV, TXT, JSON) and exit"
    )
    parser.add_argument(
        "--seed", action="store_true", help="Force re-seed live inventory from sample dataset"
    )

    args = parser.parse_args()

    storage = StorageManager(json_path="data/inventory.json", csv_path="data/inventory.csv")

    if args.seed:
        sample_csv = "data/sample_pantry.csv"
        if os.path.exists(sample_csv):
            res = storage.import_bulk_dataset(sample_csv)
            storage.save_to_json(res["valid_imported_items"])
            storage.save_to_csv(res["valid_imported_items"])
            print(f"[✔] Seeded {len(res['valid_imported_items'])} records from '{sample_csv}'.")
        else:
            print(f"[✕] Sample file '{sample_csv}' not found.")
        return

    # Seed if completely empty on first run
    seed_sample_data_if_empty(storage)

    if args.summary:
        items, _ = storage.load_from_json()
        summary = generate_executive_summary(items)
        print("\n=== EXECUTIVE PANTRY SUMMARY ===")
        print(f"Total Items:     {summary['total_items']}")
        print(f"Total Valuation: ${summary['total_value']:.2f}")
        print(f"Expired Items:   {summary['waste_risk']['expired_count']} (${summary['waste_risk']['expired_cost']:.2f})")
        print(f"Critical Items:  {summary['waste_risk']['critical_count']} (${summary['waste_risk']['critical_cost']:.2f})")
        print(f"At-Risk Value:   ${summary['waste_risk']['at_risk_value']:.2f} ({summary['waste_risk']['risk_percentage']}%)")
        return

    if args.export:
        items, _ = storage.load_from_json()
        exporter = ReportExporter(output_dir="exports")
        p1 = exporter.export_markdown_report(items)
        p2 = exporter.export_plain_text_audit(items)
        p3 = exporter.export_csv(items)
        p4 = exporter.export_json_summary(items)
        print("[✔] Successfully exported all reports:")
        print(f"  • Markdown: {p1}")
        print(f"  • Audit:    {p2}")
        print(f"  • CSV:      {p3}")
        print(f"  • JSON:     {p4}")
        return

    if args.gui:
        launch_food_tracker_gui(storage)
    else:
        cli = ExpiryTrackerCLI(json_path="data/inventory.json", csv_path="data/inventory.csv")
        cli.run()


if __name__ == "__main__":
    main()
