# 🥗 Food Expiry Tracker
> **StudentLife Hack | Project #62 | Domain: Food & Agriculture**  
> *Engineered for Hackathons, Student Pantries, and Smart Kitchen Management*

---

## 📌 1. Problem Context & Objective
In academic and student environments, roommates and individuals frequently experience friction when attempting to record pantry items and highlight food nearing its expiry date. Manual tracking leads to calculation errors, misplaced entries, food safety risks, and expensive financial waste ($50–$150/month per student household). 

Existing enterprise tools suffer from steep learning curves, expensive subscriptions, and intrusive network configurations. **Food Expiry Tracker** resolves this challenge with an accessible, high-performance, and resilient Python application engineered to streamline data handling, validate entries defensibly, persist data reliably across restarts, and present actionable executive waste summaries.

---

## 🌟 2. Feature Matrix

| Category | Feature | Status | Description |
| :--- | :--- | :---: | :--- |
| **Core (Must-Have)** | **Interactive Terminal Interface** | ✅ Built | Menu-driven CLI with ANSI formatting, ASCII banners, and paginated views. |
| **Core (Must-Have)** | **Defensive Input Validation** | ✅ Built | Real-time sanitization, regex date validation, range checks, and crash-proof prompt loops. |
| **Core (Must-Have)** | **Core Business Logic Engine** | ✅ Built | Computes days remaining, status categories, waste valuation, and priority rankings. |
| **Core (Must-Have)** | **Local Data Persistence** | ✅ Built | Dual CSV and JSON persistence with atomic writes, corrupted-file auto-backup, and recovery. |
| **Core (Must-Have)** | **Record Query & Search** | ✅ Built | Multi-criteria filtering by keyword, food category, storage location, status, and shelf life. |
| **Core (Must-Have)** | **Executive Summary Generation**| ✅ Built | Aggregates totals, averages, status distributions, storage allocations, and economic waste risk. |
| **Stretch (Good-to-Have)** | **Multi-Format Summary Export** | ✅ Built | Generates GitHub-flavored Markdown (`.md`), plain-text audit receipts (`.txt`), CSV, and JSON. |
| **Stretch (Good-to-Have)** | **Threshold Warning Indicators** | ✅ Built | Automated startup & runtime alert banners highlighting overdue hazards and ≤3-day deadlines. |
| **Stretch (Good-to-Have)** | **Interactive GUI Enhancement** | ✅ Built | Lightweight Tkinter desktop GUI with color-coded table rows, modal dialogs, and filters. |
| **Stretch (Good-to-Have)** | **Bulk Dataset Import** | ✅ Built | Ingests external/legacy CSV/JSON files with row-by-row validation and detailed error logging. |

---

## 🏗️ 3. Architecture & Repository Structure

```
food_expiry_tracker/
├── README.md                      # Comprehensive documentation & hackathon guide
├── requirements.txt               # Optional dependencies (pandas, matplotlib)
├── run.py                         # Primary application runner & CLI dispatcher
├── main.py                        # Entrypoint alias
├── test_tracker.py                # Root test runner alias
├── scripts/
│   ├── seed_data.py               # Database initialization & syncing utility
│   └── demo_validation.py         # Automated hackathon demo journey
├── data/
│   ├── inventory.json             # Live JSON database
│   ├── inventory.csv              # Live CSV database
│   ├── sample_pantry.csv          # 36 realistic benchmark records
│   └── sample_pantry.json         # Benchmarks in JSON format
├── exports/                       # Auto-generated reports and audit logs
│   ├── expiry_summary_report.md   # Formatted Markdown executive briefing
│   ├── audit_log.txt              # Plain-text itemized receipt
│   ├── inventory_export.csv       # Standardized CSV spreadsheet
│   └── inventory_summary.json     # Machine-readable JSON summary
├── tests/
│   └── test_tracker.py            # 23 automated unit & integration tests
└── src/
    ├── __init__.py
    ├── models.py                  # FoodItem dataclass, FoodCategory, StorageLocation, ExpiryStatus
    ├── validation.py              # Defensive prompt wrappers & schema checks
    ├── storage.py                 # Persistence engine with atomic file writes & corruption recovery
    ├── business_logic.py          # Shelf life math, waste risk valuation & anomaly auditor
    ├── search_filter.py           # Multi-criteria search, filters, and sorters
    ├── analytics.py               # Aggregation module (pure Python + optional Pandas)
    ├── visualizer.py              # Paginated tables, ANSI badges, ASCII bar charts, Matplotlib hook
    ├── exporter.py                # Multi-format report generation engine
    ├── cli.py                     # Interactive menu-driven console loop
    └── gui.py                     # Lightweight Tkinter GUI enhancement
```

---

## ⚡ 4. Quick Start & Execution

### Prerequisites
- Python 3.10+ (tested on Python 3.10 through Python 3.14)
- **Zero External Dependencies Required**: The application runs completely out-of-the-box using the Python standard library (`csv`, `json`, `dataclasses`, `datetime`, `re`, `math`, `tkinter`, `unittest`).

### Launch Options

1. **Launch Interactive Terminal CLI (Default)**:
   ```bash
   python run.py
   # or
   python main.py
   ```

2. **Launch Graphical User Interface (Tkinter GUI)**:
   ```bash
   python run.py --gui
   ```

3. **Print Executive Summary & Waste Risk**:
   ```bash
   python run.py --summary
   ```

4. **Export All Multi-Format Reports**:
   ```bash
   python run.py --export
   ```

5. **Run Automated Test Suite (23 Tests)**:
   ```bash
   python test_tracker.py
   ```

6. **Execute Automated Demo Walkthrough**:
   ```bash
   python scripts/demo_validation.py
   ```

---

## 🛡️ 5. Defensive Input Validation

To eliminate program crashes caused by invalid, blank, or non-numeric terminal input, all entries pass through centralized defensive wrappers:
- **String Sanitization**: Automatically strips whitespace and removes dangerous control characters.
- **Smart Date Parsing**: Accepts standard `YYYY-MM-DD` as well as human shortcuts:
  - `today` / `now`
  - `tomorrow` / `+1d`
  - `+3d` (3 days from now)
  - `+2w` (2 weeks from now)
  - `+1m` (30 days from now)
- **Boundary Checks**:
  - Quantity: strictly positive floats (`0.01` to `100,000.00`).
  - Unit Cost: non-negative floats (`$0.00` to `$100,000.00`).
  - Item Name: length constraints (minimum 2 characters, max 100).
- **Graceful Retries**: Input loops re-prompt the user with specific, helpful error messages without terminating the program.

---

## 💾 6. Fault-Tolerant Persistence & Recovery

The `StorageManager` encapsulates reading and writing with enterprise-grade resilience:
1. **Missing Files**: Automatically creates a fresh, valid database template without raising `FileNotFoundError`.
2. **Corrupted Storage**: If a file is malformed or corrupted by manual editing, the system intercepts `json.JSONDecodeError`, preserves the damaged file as `<filename>.corrupt_<timestamp>.bak` so no data is permanently lost, and re-initializes a clean working database.
3. **Atomic File Writes**: Serializes data to temporary `.tmp` files first, performing an atomic filesystem replace to prevent partially written records if power or execution is interrupted.
4. **Bulk CSV/JSON Import**: Scans legacy datasets row-by-row, recording all valid entries and logging exact row numbers and violation reasons for invalid rows.

---

## 📊 7. Executive Analytics & Waste Risk

The analytics engine categorizes inventory into four actionable status indicators:
- 🚨 **Expired (<0 days)**: Poses food safety risks; immediate disposal required.
- ⚠️ **Critical (0–3 days)**: Expiring imminently; prioritize for immediate consumption.
- ℹ️ **Expiring Soon (4–7 days)**: Plan upcoming meals around these items.
- 🍏 **Safe / Fresh (>7 days)**: Stable pantry/freezer inventory.

### Economic Risk Formula
$$\text{At-Risk Value} = \sum (\text{Expired Cost}) + \sum (\text{Critical Cost})$$
$$\text{Risk Percentage} = \left(\frac{\text{At-Risk Value}}{\text{Total Inventory Value}}\right) \times 100$$

---

## 🎬 8. What a Good Demo Looks Like (Hackathon Walkthrough)

1. **Launch**: Run `python run.py`. The console presents a branded welcome screen, summary count, and automated threshold alerts (e.g. `🚨 4 item(s) are EXPIRED!`).
2. **Browse Records**: Select `[1]` to explore the paginated inventory table with color-coded shelf status badges and page navigation (`[N]ext`, `[P]rev`, `[S]ort`).
3. **Defensive Validation Demo**: Select `[2]` to add an item. Intentionally test negative quantities, bad date formats (e.g. `invalid-date`), and blank names to prove the validation engine catches and explains the error before accepting a valid entry like `+3d`.
4. **Analytics & Trends**: Select `[4]` to review portfolio valuation, total monetary waste risk, and high-fidelity ASCII horizontal distribution charts.
5. **Data Persistence Proof**: Exit the application (`[0]`), re-launch it with `python run.py`, and observe that the newly recorded item is preserved in the database.
6. **Multi-Format Export**: Select `[6]` to generate Markdown, plain-text audit receipts, and CSV reports inside `exports/`.
7. **GUI Showcase**: Select `[9]` (or run `python run.py --gui`) to showcase the Tkinter desktop GUI with color-coded rows, live search, and modal creation dialog.

---

## 🧪 9. Automated Test Suite

Run the full automated test suite anytime:
```bash
python -m unittest tests/test_tracker.py
```
**Test Results:**
```
Ran 23 tests in 0.179s
OK (23 passed, 0 failures, 0 errors)
```
- `TestFoodItemModel`: Verifies dataclass instantiation, computed properties, and dictionary transformations.
- `TestValidation`: Tests string sanitization, relative date parsing (`+3d`, `+2w`), and boundary checks.
- `TestBusinessLogic`: Validates shelf-life computations, waste risk percentages, threshold alerts, and anomaly detection.
- `TestStorageManager`: Verifies JSON/CSV roundtrips, atomic writes, missing file handling, and corrupt file backup.
- `TestSearchAndFilter`: Tests substring searches, category filtering, storage location matching, and sorting.
- `TestAnalyticsAndReports`: Verifies executive aggregation math and file export generators.

---
*Built with ❤️ for StudentLife Hack Project #62 | Domain: Food & Agriculture*
