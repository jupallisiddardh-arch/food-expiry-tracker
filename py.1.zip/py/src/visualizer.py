"""Terminal visualization engine and optional Matplotlib chart generator.

Provides clean tabular formatting with fixed column widths, ANSI status indicators,
pagination breaks for large datasets, and ASCII bar charts.
"""

import os
from typing import List, Dict, Any, Optional, Tuple
from datetime import date

from src.models import FoodItem, ExpiryStatus

# ANSI styling constants
ANSI_RESET = "\033[0m"
ANSI_BOLD = "\033[1m"
ANSI_DIM = "\033[2m"
ANSI_RED = "\033[91m"
ANSI_GREEN = "\033[92m"
ANSI_YELLOW = "\033[93m"
ANSI_BLUE = "\033[94m"
ANSI_MAGENTA = "\033[95m"
ANSI_CYAN = "\033[96m"
ANSI_WHITE = "\033[97m"
ANSI_BG_RED = "\033[41m"
ANSI_BG_YELLOW = "\033[43m"


def get_status_badge(item: FoodItem, ref_date: Optional[date] = None) -> str:
    """Return ANSI-colored status string."""
    status = item.status(ref_date)
    days = item.days_remaining(ref_date)
    if status == ExpiryStatus.EXPIRED:
        return f"{ANSI_RED}EXPIRED ({abs(days)}d ago){ANSI_RESET}"
    elif status == ExpiryStatus.CRITICAL:
        if days == 0:
            return f"{ANSI_YELLOW}TODAY (0d left){ANSI_RESET}"
        return f"{ANSI_YELLOW}CRITICAL ({days}d left){ANSI_RESET}"
    elif status == ExpiryStatus.EXPIRING_SOON:
        return f"{ANSI_CYAN}SOON ({days}d left){ANSI_RESET}"
    else:
        return f"{ANSI_GREEN}FRESH ({days}d left){ANSI_RESET}"


def format_table(items: List[FoodItem], page: int = 1, page_size: int = 10, ref_date: Optional[date] = None) -> Tuple[str, int, int]:
    """
    Format FoodItems as an aligned tabular view with fixed character widths,
    status badges, and pagination indicators.
    """
    if not items:
        return f"\n{ANSI_DIM}No pantry items found matching criteria.{ANSI_RESET}\n", 1, 1

    total_items = len(items)
    total_pages = max(1, (total_items + page_size - 1) // page_size)
    curr_page = max(1, min(page, total_pages))

    start_idx = (curr_page - 1) * page_size
    end_idx = min(start_idx + page_size, total_items)
    page_items = items[start_idx:end_idx]

    # Column dimensions
    # ID(8) | Name(22) | Category(14) | Storage(10) | Qty(10) | Expiry(12) | Status(20) | Value(8)
    header = (
        f"{ANSI_BOLD}{'ID':<9} | {'Item Name':<22} | {'Category':<15} | "
        f"{'Location':<11} | {'Quantity':<10} | {'Expiry Date':<11} | "
        f"{'Shelf Status':<22} | {'Total $':<8}{ANSI_RESET}"
    )
    separator = "-" * 122

    rows = [separator, header, separator]

    for it in page_items:
        name_str = (it.name[:19] + "...") if len(it.name) > 22 else it.name
        cat_str = (it.category[:12] + "...") if len(it.category) > 15 else it.category
        loc_str = it.storage_location[:11]
        qty_str = f"{it.quantity} {it.unit}"[:10]
        exp_str = it.expiry_date
        status_str = get_status_badge(it, ref_date)
        # Handle padding for ANSI escape codes (badge has formatting codes that don't take visual width)
        # Visual length of badge:
        vis_len = 22
        val_str = f"${it.total_cost:>6.2f}"

        row_line = (
            f"{it.id:<9} | {name_str:<22} | {cat_str:<15} | "
            f"{loc_str:<11} | {qty_str:<10} | {exp_str:<11} | "
            f"{status_str:<32} | {val_str:<8}"
        )
        rows.append(row_line)

    rows.append(separator)
    footer = f"{ANSI_DIM}Showing records {start_idx + 1}-{end_idx} of {total_items} | Page {curr_page} of {total_pages}{ANSI_RESET}"
    rows.append(footer)

    return "\n".join(rows), curr_page, total_pages


def render_ascii_bar_chart(title: str, data: Dict[str, float], total: Optional[float] = None, bar_width: int = 25) -> str:
    """Generate a clean ASCII horizontal bar chart."""
    if not data:
        return f"{title}\n  (No data available)"

    lines = [f"\n{ANSI_BOLD}{title}{ANSI_RESET}"]
    calc_total = total if total and total > 0 else sum(data.values())
    if calc_total == 0:
        calc_total = 1.0

    max_label_len = max(len(k) for k in data.keys())

    for label, val in data.items():
        pct = (val / calc_total) * 100
        filled = int((val / calc_total) * bar_width)
        bar = "█" * filled + "░" * (bar_width - filled)
        
        # Color coding if status
        color = ANSI_WHITE
        if "Expired" in label:
            color = ANSI_RED
        elif "Critical" in label:
            color = ANSI_YELLOW
        elif "Soon" in label:
            color = ANSI_CYAN
        elif "Safe" in label or "Fresh" in label:
            color = ANSI_GREEN

        lines.append(f"  {label:<{max_label_len}} {color}[{bar}]{ANSI_RESET} {pct:>5.1f}% ({val:.0f})")

    return "\n".join(lines)


def render_matplotlib_charts(items: List[FoodItem], output_dir: str = "exports") -> Optional[Dict[str, str]]:
    """
    Optional stretch feature: generate graphical charts with Matplotlib if installed.
    Returns dictionary of generated chart image paths, or None if matplotlib is not available.
    """
    try:
        import matplotlib
        matplotlib.use("Agg")  # Non-interactive backend
        import matplotlib.pyplot as plt

        os.makedirs(output_dir, exist_ok=True)
        paths = {}

        # Chart 1: Expiry Status Distribution Pie/Bar
        status_counts = {s.value: 0 for s in ExpiryStatus}
        for it in items:
            status_counts[it.status().value] += 1

        labels = [k for k, v in status_counts.items() if v > 0]
        sizes = [v for k, v in status_counts.items() if v > 0]
        colors = ["#e74c3c", "#f39c12", "#3498db", "#2ecc71"][:len(labels)]

        if sizes:
            fig, ax = plt.subplots(figsize=(6, 5))
            ax.pie(sizes, labels=labels, autopct='%1.1f%%', colors=colors, startangle=140)
            ax.set_title("Food Pantry - Expiry Status Distribution")
            chart1_path = os.path.join(output_dir, "expiry_status_chart.png")
            plt.savefig(chart1_path, bbox_inches="tight", dpi=150)
            plt.close(fig)
            paths["status_chart"] = chart1_path

        # Chart 2: Category Breakdown Bar Chart
        categories = {}
        for it in items:
            cat = it.category or "Other"
            categories[cat] = categories.get(cat, 0) + 1

        if categories:
            fig, ax = plt.subplots(figsize=(8, 4.5))
            cats = list(categories.keys())
            counts = list(categories.values())
            ax.barh(cats, counts, color="#34495e")
            ax.set_xlabel("Item Count")
            ax.set_title("Inventory Distribution by Category")
            plt.tight_layout()
            chart2_path = os.path.join(output_dir, "category_distribution_chart.png")
            plt.savefig(chart2_path, bbox_inches="tight", dpi=150)
            plt.close(fig)
            paths["category_chart"] = chart2_path

        return paths

    except ImportError:
        return None
    except Exception:
        return None
