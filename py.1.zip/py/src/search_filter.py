"""Search, query, and multi-criteria filtering engine for pantry inventory."""

from typing import List, Optional
from datetime import date
from src.models import FoodItem, ExpiryStatus


def search_by_keyword(items: List[FoodItem], keyword: str) -> List[FoodItem]:
    """Search items by keyword in name, category, storage location, or notes (case-insensitive)."""
    kw = keyword.strip().lower()
    if not kw:
        return items
    return [
        it for it in items
        if kw in it.name.lower()
        or kw in it.category.lower()
        or kw in it.storage_location.lower()
        or kw in it.notes.lower()
        or kw in it.id.lower()
    ]


def filter_by_category(items: List[FoodItem], category: str) -> List[FoodItem]:
    """Filter items strictly or partially matching category name."""
    cat = category.strip().lower()
    if not cat or cat == "all":
        return items
    return [it for it in items if cat in it.category.lower()]


def filter_by_storage(items: List[FoodItem], storage_location: str) -> List[FoodItem]:
    """Filter items matching storage location (e.g. Fridge, Pantry, Freezer)."""
    loc = storage_location.strip().lower()
    if not loc or loc == "all":
        return items
    return [it for it in items if loc in it.storage_location.lower()]


def filter_by_status(items: List[FoodItem], status: ExpiryStatus, ref_date: Optional[date] = None) -> List[FoodItem]:
    """Filter items by ExpiryStatus enum."""
    return [it for it in items if it.status(ref_date) == status]


def filter_by_days_range(items: List[FoodItem], min_days: Optional[int] = None, max_days: Optional[int] = None, ref_date: Optional[date] = None) -> List[FoodItem]:
    """Filter items whose remaining shelf days fall within [min_days, max_days]."""
    results: List[FoodItem] = []
    for it in items:
        days = it.days_remaining(ref_date)
        if min_days is not None and days < min_days:
            continue
        if max_days is not None and days > max_days:
            continue
        results.append(it)
    return results


def sort_items(items: List[FoodItem], sort_by: str = "expiry", ascending: bool = True, ref_date: Optional[date] = None) -> List[FoodItem]:
    """
    Sort items by field:
      - 'expiry': days remaining (soonest first if ascending)
      - 'name': alphabetical
      - 'category': alphabetical by category
      - 'quantity': by quantity
      - 'cost': by total monetary value
      - 'added': by timestamp
    """
    key_func = {
        "expiry": lambda it: it.days_remaining(ref_date),
        "name": lambda it: it.name.lower(),
        "category": lambda it: it.category.lower(),
        "quantity": lambda it: it.quantity,
        "cost": lambda it: it.total_cost,
        "added": lambda it: it.added_at,
    }.get(sort_by, lambda it: it.days_remaining(ref_date))

    return sorted(items, key=key_func, reverse=not ascending)
