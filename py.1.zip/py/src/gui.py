"""Lightweight Tkinter Graphical User Interface (GUI) Enhancement.

Provides a desktop window with color-coded inventory treeview, live search,
modal dialogs for adding/editing items, and one-click report exports.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date
from typing import Optional

from src.models import FoodItem, FoodCategory, StorageLocation, ExpiryStatus
from src.storage import StorageManager
from src.analytics import generate_executive_summary
from src.exporter import ReportExporter
from src.validation import validate_date_string


class FoodTrackerGUI(tk.Tk):
    """Tkinter desktop interface for Food Expiry Tracker."""

    def __init__(self, storage_manager: Optional[StorageManager] = None):
        super().__init__()
        self.title("Food Expiry Tracker - StudentLife Hack")
        self.geometry("1100x680")
        self.minsize(900, 550)

        self.storage = storage_manager or StorageManager()
        self.exporter = ReportExporter()
        self.items = []

        self._configure_styles()
        self._build_ui()
        self._load_inventory()

    def _configure_styles(self):
        """Configure ttk styles and treeview color tags."""
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except Exception:
            pass

        self.style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))
        self.style.configure("Treeview", font=("Segoe UI", 9), rowheight=26)

    def _build_ui(self):
        """Construct GUI layout."""
        # Header banner
        header_frame = tk.Frame(self, bg="#2c3e50", height=60)
        header_frame.pack(fill=tk.X, side=tk.TOP)

        title_lbl = tk.Label(
            header_frame,
            text="🥗 Food Expiry Tracker",
            font=("Segoe UI", 16, "bold"),
            bg="#2c3e50",
            fg="#ecf0f1"
        )
        title_lbl.pack(side=tk.LEFT, padx=15, pady=10)

        subtitle_lbl = tk.Label(
            header_frame,
            text="StudentLife Hack #62 | Food & Agriculture",
            font=("Segoe UI", 9, "italic"),
            bg="#2c3e50",
            fg="#bdc3c7"
        )
        subtitle_lbl.pack(side=tk.LEFT, padx=5, pady=12)

        # Stats Toolbar
        self.stats_frame = tk.Frame(self, bg="#ecf0f1", height=35)
        self.stats_frame.pack(fill=tk.X, side=tk.TOP, padx=10, pady=5)

        self.stats_label = tk.Label(
            self.stats_frame,
            text="Loading inventory statistics...",
            font=("Segoe UI", 10, "bold"),
            bg="#ecf0f1",
            fg="#2c3e50"
        )
        self.stats_label.pack(side=tk.LEFT, padx=10, pady=5)

        # Search and Filter Toolbar
        filter_frame = tk.Frame(self)
        filter_frame.pack(fill=tk.X, side=tk.TOP, padx=10, pady=5)

        tk.Label(filter_frame, text="🔍 Search:").pack(side=tk.LEFT, padx=2)
        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *args: self._apply_filters())
        self.search_entry = ttk.Entry(filter_frame, textvariable=self.search_var, width=18)
        self.search_entry.pack(side=tk.LEFT, padx=5)

        tk.Label(filter_frame, text="Category:").pack(side=tk.LEFT, padx=5)
        self.cat_var = tk.StringVar(value="All")
        cat_options = ["All"] + FoodCategory.list_all()
        self.cat_combo = ttk.Combobox(filter_frame, textvariable=self.cat_var, values=cat_options, state="readonly", width=15)
        self.cat_combo.pack(side=tk.LEFT, padx=2)
        self.cat_combo.bind("<<ComboboxSelected>>", lambda e: self._apply_filters())

        tk.Label(filter_frame, text="Status:").pack(side=tk.LEFT, padx=5)
        self.status_var = tk.StringVar(value="All")
        stat_options = ["All", "Expired", "Critical", "Expiring Soon", "Safe"]
        self.status_combo = ttk.Combobox(filter_frame, textvariable=self.status_var, values=stat_options, state="readonly", width=14)
        self.status_combo.pack(side=tk.LEFT, padx=2)
        self.status_combo.bind("<<ComboboxSelected>>", lambda e: self._apply_filters())

        btn_refresh = ttk.Button(filter_frame, text="Reset Filters", command=self._reset_filters)
        btn_refresh.pack(side=tk.LEFT, padx=10)

        # Inventory Table Frame
        table_frame = tk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        cols = ("id", "name", "category", "storage", "qty", "unit", "expiry", "days", "status", "cost")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings", selectmode="browse")

        self.tree.heading("id", text="ID")
        self.tree.heading("name", text="Item Name")
        self.tree.heading("category", text="Category")
        self.tree.heading("storage", text="Location")
        self.tree.heading("qty", text="Qty")
        self.tree.heading("unit", text="Unit")
        self.tree.heading("expiry", text="Expiry Date")
        self.tree.heading("days", text="Days Left")
        self.tree.heading("status", text="Shelf Status")
        self.tree.heading("cost", text="Total ($)")

        self.tree.column("id", width=80, anchor=tk.CENTER)
        self.tree.column("name", width=180, anchor=tk.W)
        self.tree.column("category", width=130, anchor=tk.W)
        self.tree.column("storage", width=100, anchor=tk.CENTER)
        self.tree.column("qty", width=60, anchor=tk.E)
        self.tree.column("unit", width=70, anchor=tk.W)
        self.tree.column("expiry", width=100, anchor=tk.CENTER)
        self.tree.column("days", width=80, anchor=tk.CENTER)
        self.tree.column("status", width=130, anchor=tk.CENTER)
        self.tree.column("cost", width=80, anchor=tk.E)

        # Scrollbars
        v_scroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=v_scroll.set)
        v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)

        # Configure color tags
        self.tree.tag_configure("expired", background="#fadbd8", foreground="#78281f")
        self.tree.tag_configure("critical", background="#fdebd0", foreground="#7e5109")
        self.tree.tag_configure("expiring_soon", background="#d4efdf", foreground="#145a32")
        self.tree.tag_configure("safe", background="#ffffff", foreground="#1b2631")

        # Bottom Action Buttons Frame
        btn_frame = tk.Frame(self, pady=8)
        btn_frame.pack(fill=tk.X, side=tk.BOTTOM, padx=10)

        btn_add = tk.Button(btn_frame, text="➕ Add Item", bg="#27ae60", fg="white", font=("Segoe UI", 9, "bold"), padx=10, command=self._open_add_dialog)
        btn_add.pack(side=tk.LEFT, padx=5)

        btn_delete = tk.Button(btn_frame, text="🗑 Delete Selected", bg="#c0392b", fg="white", font=("Segoe UI", 9, "bold"), padx=10, command=self._delete_selected)
        btn_delete.pack(side=tk.LEFT, padx=5)

        btn_analytics = tk.Button(btn_frame, text="📊 Analytics Summary", bg="#2980b9", fg="white", font=("Segoe UI", 9, "bold"), padx=10, command=self._view_analytics_popup)
        btn_analytics.pack(side=tk.LEFT, padx=5)

        btn_export = tk.Button(btn_frame, text="📁 Export Reports", bg="#8e44ad", fg="white", font=("Segoe UI", 9, "bold"), padx=10, command=self._export_reports)
        btn_export.pack(side=tk.LEFT, padx=5)

        btn_import = tk.Button(btn_frame, text="📥 Ingest Dataset", bg="#d35400", fg="white", font=("Segoe UI", 9, "bold"), padx=10, command=self._import_dataset_file)
        btn_import.pack(side=tk.LEFT, padx=5)

        btn_close = tk.Button(btn_frame, text="Close GUI", bg="#7f8c8d", fg="white", font=("Segoe UI", 9), padx=10, command=self.destroy)
        btn_close.pack(side=tk.RIGHT, padx=5)

    def _load_inventory(self):
        """Load data from storage and populate table."""
        self.items, _ = self.storage.load_from_json()
        self._apply_filters()

    def _save_inventory(self):
        """Save data to both JSON and CSV."""
        self.storage.save_to_json(self.items)
        self.storage.save_to_csv(self.items)
        self._apply_filters()

    def _reset_filters(self):
        self.search_var.set("")
        self.cat_var.set("All")
        self.status_var.set("All")
        self._apply_filters()

    def _apply_filters(self):
        """Filter table items by search text, category, and status."""
        for row in self.tree.get_children():
            self.tree.delete(row)

        kw = self.search_var.get().strip().lower()
        cat = self.cat_var.get()
        stat_filter = self.status_var.get()

        filtered = []
        for it in self.items:
            # Keyword filter
            if kw and (kw not in it.name.lower() and kw not in it.category.lower() and kw not in it.id.lower()):
                continue
            # Category filter
            if cat != "All" and cat != it.category:
                continue
            # Status filter
            st = it.status()
            if stat_filter == "Expired" and st != ExpiryStatus.EXPIRED:
                continue
            elif stat_filter == "Critical" and st != ExpiryStatus.CRITICAL:
                continue
            elif stat_filter == "Expiring Soon" and st != ExpiryStatus.EXPIRING_SOON:
                continue
            elif stat_filter == "Safe" and st != ExpiryStatus.SAFE:
                continue

            filtered.append(it)

        # Sort filtered items by days remaining
        filtered.sort(key=lambda x: x.days_remaining())

        # Populate treeview
        for it in filtered:
            days = it.days_remaining()
            status_obj = it.status()
            if status_obj == ExpiryStatus.EXPIRED:
                tag = "expired"
            elif status_obj == ExpiryStatus.CRITICAL:
                tag = "critical"
            elif status_obj == ExpiryStatus.EXPIRING_SOON:
                tag = "expiring_soon"
            else:
                tag = "safe"

            days_disp = f"{days}d" if days >= 0 else f"{days}d (EXPIRED)"
            self.tree.insert(
                "",
                tk.END,
                values=(
                    it.id,
                    it.name,
                    it.category,
                    it.storage_location,
                    it.quantity,
                    it.unit,
                    it.expiry_date,
                    days_disp,
                    status_obj.value,
                    f"${it.total_cost:.2f}"
                ),
                tags=(tag,)
            )

        # Update stats
        summary = generate_executive_summary(self.items)
        wr = summary["waste_risk"]
        stats_text = (
            f"📦 Items: {summary['total_items']}  |  "
            f"💰 Portfolio: ${summary['total_value']:.2f}  |  "
            f"🚨 Expired: {wr['expired_count']} (${wr['expired_cost']:.2f})  |  "
            f"⚠️ Critical (≤3d): {wr['critical_count']} (${wr['critical_cost']:.2f})  |  "
            f"⚡ Total at Risk: ${wr['at_risk_value']:.2f}"
        )
        self.stats_label.config(text=stats_text)

    def _open_add_dialog(self):
        """Open modal dialog to input a new food item."""
        dialog = tk.Toplevel(self)
        dialog.title("Add New Pantry Item")
        dialog.geometry("420x480")
        dialog.transient(self)
        dialog.grab_set()

        # Compute next ID
        existing_nums = []
        for it in self.items:
            if it.id.startswith("ITEM-"):
                try:
                    existing_nums.append(int(it.id.split("-")[1]))
                except ValueError:
                    pass
        next_id = f"ITEM-{max(existing_nums, default=0) + 1:03d}"

        tk.Label(dialog, text="Add New Pantry Item", font=("Segoe UI", 12, "bold")).pack(pady=10)

        form = tk.Frame(dialog, padx=15)
        form.pack(fill=tk.BOTH, expand=True)

        row = 0
        tk.Label(form, text="Item ID:").grid(row=row, column=0, sticky="w", pady=4)
        id_entry = ttk.Entry(form)
        id_entry.insert(0, next_id)
        id_entry.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Item Name:").grid(row=row, column=0, sticky="w", pady=4)
        name_entry = ttk.Entry(form)
        name_entry.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Category:").grid(row=row, column=0, sticky="w", pady=4)
        cat_combo = ttk.Combobox(form, values=FoodCategory.list_all(), state="readonly")
        cat_combo.set(FoodCategory.DAIRY.value)
        cat_combo.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Storage:").grid(row=row, column=0, sticky="w", pady=4)
        loc_combo = ttk.Combobox(form, values=StorageLocation.list_all(), state="readonly")
        loc_combo.set(StorageLocation.FRIDGE.value)
        loc_combo.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Quantity:").grid(row=row, column=0, sticky="w", pady=4)
        qty_entry = ttk.Entry(form)
        qty_entry.insert(0, "1.0")
        qty_entry.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Unit:").grid(row=row, column=0, sticky="w", pady=4)
        unit_entry = ttk.Entry(form)
        unit_entry.insert(0, "units")
        unit_entry.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Purchase Date:").grid(row=row, column=0, sticky="w", pady=4)
        p_entry = ttk.Entry(form)
        p_entry.insert(0, date.today().strftime("%Y-%m-%d"))
        p_entry.grid(row=row, column=1, sticky="ew", pady=4)

        row += 1
        tk.Label(form, text="Expiry Date:").grid(row=row, column=0, sticky="w", pady=4)
        exp_entry = ttk.Entry(form)
        exp_entry.grid(row=row, column=1, sticky="ew", pady=4)
        tk.Label(form, text="(e.g. YYYY-MM-DD or '+5d')", font=("Segoe UI", 8, "italic")).grid(row=row+1, column=1, sticky="w")

        row += 2
        tk.Label(form, text="Unit Cost ($):").grid(row=row, column=0, sticky="w", pady=4)
        cost_entry = ttk.Entry(form)
        cost_entry.insert(0, "0.00")
        cost_entry.grid(row=row, column=1, sticky="ew", pady=4)

        def save_item():
            item_id = id_entry.get().strip()
            name = name_entry.get().strip()
            if not item_id or not name:
                messagebox.showerror("Validation Error", "Item ID and Name are required.", parent=dialog)
                return

            if any(it.id == item_id for it in self.items):
                messagebox.showerror("Validation Error", f"Item ID '{item_id}' already exists.", parent=dialog)
                return

            try:
                qty = float(qty_entry.get().strip())
                if qty <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Validation Error", "Quantity must be a positive number.", parent=dialog)
                return

            try:
                cost = float(cost_entry.get().strip())
                if cost < 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Validation Error", "Unit cost cannot be negative.", parent=dialog)
                return

            # Validate date
            ok, exp_date_parsed, err = validate_date_string(exp_entry.get().strip())
            if not ok or not exp_date_parsed:
                messagebox.showerror("Validation Error", f"Invalid expiry date: {err}", parent=dialog)
                return

            new_item = FoodItem(
                id=item_id,
                name=name,
                category=cat_combo.get(),
                storage_location=loc_combo.get(),
                quantity=qty,
                unit=unit_entry.get().strip() or "units",
                purchase_date=p_entry.get().strip() or date.today().strftime("%Y-%m-%d"),
                expiry_date=exp_date_parsed.strftime("%Y-%m-%d"),
                unit_cost=cost
            )

            self.items.append(new_item)
            self._save_inventory()
            dialog.destroy()
            messagebox.showinfo("Success", f"Recorded '{name}' successfully!", parent=self)

        btn_save = tk.Button(dialog, text="Save Food Item", bg="#27ae60", fg="white", font=("Segoe UI", 10, "bold"), command=save_item)
        btn_save.pack(pady=15)

    def _delete_selected(self):
        """Delete currently selected treeview item."""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Notice", "Please select an item from the table to delete.", parent=self)
            return

        values = self.tree.item(selected[0], "values")
        item_id = values[0]
        item_name = values[1]

        if messagebox.askyesno("Confirm Deletion", f"Permanently delete '{item_name}' [{item_id}]?", parent=self):
            self.items = [it for it in self.items if it.id != item_id]
            self._save_inventory()

    def _view_analytics_popup(self):
        """Display an analytics summary dialog."""
        summary = generate_executive_summary(self.items)
        wr = summary["waste_risk"]

        info = (
            f"=== PANTRY ANALYTICS SUMMARY ===\n\n"
            f"Total Inventory Records:   {summary['total_items']}\n"
            f"Total Physical Quantity:   {summary['total_quantity']} units\n"
            f"Total Monetary Valuation:  ${summary['total_value']:.2f}\n"
            f"Average Cost Per Item:     ${summary['average_item_cost']:.2f}\n"
            f"Average Shelf Life:        {summary['average_days_remaining']} days\n\n"
            f"--- WASTE & EXPIRY RISK ---\n"
            f"🚨 Expired Items:          {wr['expired_count']} (${wr['expired_cost']:.2f})\n"
            f"⚠️ Critical (≤3 days):     {wr['critical_count']} (${wr['critical_cost']:.2f})\n"
            f"⚡ Total Value at Risk:    ${wr['at_risk_value']:.2f} ({wr['risk_percentage']}%)\n\n"
            f"--- STATUS BREAKDOWN ---\n"
        )
        for s, count in summary["status_counts"].items():
            info += f"  • {s}: {count} ({summary['status_percentages'].get(s, 0)}%)\n"

        messagebox.showinfo("Executive Analytics Dashboard", info, parent=self)

    def _export_reports(self):
        """Export all reports and notify user."""
        p_md = self.exporter.export_markdown_report(self.items)
        p_txt = self.exporter.export_plain_text_audit(self.items)
        p_csv = self.exporter.export_csv(self.items)
        p_json = self.exporter.export_json_summary(self.items)

        msg = (
            f"Successfully exported reports:\n\n"
            f"• Markdown Report: {p_md}\n"
            f"• Plain-Text Audit: {p_txt}\n"
            f"• Standard CSV: {p_csv}\n"
            f"• JSON Summary: {p_json}"
        )
        messagebox.showinfo("Reports Exported", msg, parent=self)

    def _import_dataset_file(self):
        """Browse and ingest external dataset file."""
        filepath = filedialog.askopenfilename(
            title="Select CSV or JSON Dataset to Ingest",
            filetypes=[("CSV and JSON Files", "*.csv;*.json"), ("All Files", "*.*")]
        )
        if not filepath:
            return

        result = self.storage.import_bulk_dataset(filepath)
        valid_items = result["valid_imported_items"]
        errors = result["error_log"]

        msg = f"Import Processed {result['total_rows_read']} rows:\n"
        msg += f"✔ Valid items: {len(valid_items)}\n"
        msg += f"✕ Errors / Skipped: {len(errors)}\n\n"
        if errors:
            msg += f"Sample Error: {errors[0]}\n\n"
        msg += f"Merge {len(valid_items)} records into current inventory?"

        if messagebox.askyesno("Confirm Dataset Ingestion", msg, parent=self):
            existing_ids = {it.id for it in self.items}
            for new_it in valid_items:
                if new_it.id in existing_ids:
                    self.items = [it if it.id != new_it.id else new_it for it in self.items]
                else:
                    self.items.append(new_it)
                    existing_ids.add(new_it.id)

            self._save_inventory()
            messagebox.showinfo("Success", f"Ingested {len(valid_items)} records successfully!", parent=self)


def launch_food_tracker_gui(storage_manager: Optional[StorageManager] = None):
    """Launch Tkinter application mainloop."""
    app = FoodTrackerGUI(storage_manager)
    app.mainloop()
