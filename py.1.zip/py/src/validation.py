"""Defensive input validation, sanitization, and console prompt wrappers.

Prevents crashes resulting from invalid types, blank values, or boundary violations.
"""

import re
from datetime import datetime, date, timedelta
from typing import Tuple, List, Optional, Any, Dict


ANSI_RED = "\033[91m"
ANSI_YELLOW = "\033[93m"
ANSI_GREEN = "\033[92m"
ANSI_CYAN = "\033[96m"
ANSI_RESET = "\033[0m"


def sanitize_string(val: Any) -> str:
    """Strip leading/trailing whitespace and remove non-printable characters."""
    if val is None:
        return ""
    text = str(val).strip()
    return re.sub(r"[\x00-\x1f\x7f-\x9f]", "", text)


def validate_date_string(date_str: str) -> Tuple[bool, Optional[date], str]:
    """
    Validate and parse a date string.
    Supports formats:
      - 'YYYY-MM-DD'
      - 'today' or 'now'
      - '+Nd' e.g. '+3d' for 3 days from today
      - '+Nw' e.g. '+2w' for 2 weeks from today
      - '+Nm' e.g. '+1m' for 30 days from today
    Returns: (is_valid, parsed_date, error_message)
    """
    cleaned = sanitize_string(date_str).lower()
    if not cleaned:
        return False, None, "Date cannot be empty."

    today = date.today()

    # Convenience shortcuts
    if cleaned in ("today", "now", "0d"):
        return True, today, ""
    if cleaned in ("tomorrow", "+1d", "1d"):
        return True, today + timedelta(days=1), ""
    if cleaned in ("yesterday", "-1d"):
        return True, today - timedelta(days=1), ""

    # Relative shortcuts like +5d, +2w, +3m, -2d
    rel_match = re.match(r"^([+-]?\d+)\s*([dwm])$", cleaned)
    if rel_match:
        qty = int(rel_match.group(1))
        unit = rel_match.group(2)
        if unit == "d":
            return True, today + timedelta(days=qty), ""
        elif unit == "w":
            return True, today + timedelta(weeks=qty), ""
        elif unit == "m":
            return True, today + timedelta(days=qty * 30), ""

    # Standard YYYY-MM-DD format
    try:
        parsed = datetime.strptime(cleaned, "%Y-%m-%d").date()
        # Reasonable boundary validation (between 1990 and 2100)
        if parsed.year < 1990 or parsed.year > 2100:
            return False, None, f"Year {parsed.year} out of reasonable range (1990-2100)."
        return True, parsed, ""
    except ValueError:
        return False, None, f"Invalid date format '{date_str}'. Expected YYYY-MM-DD or shortcut (e.g., '+5d', 'today')."


def validate_food_item_dict(d: Dict[str, Any]) -> Tuple[bool, Dict[str, Any], List[str]]:
    """
    Perform deep validation on a raw food item dictionary (e.g. from CSV row or user payload).
    Returns (is_valid, sanitized_item_dict, list_of_errors).
    """
    errors: List[str] = []
    cleaned: Dict[str, Any] = {}

    # 1. ID
    item_id = sanitize_string(d.get("id", ""))
    if not item_id:
        errors.append("Item ID is required.")
    cleaned["id"] = item_id

    # 2. Name
    name = sanitize_string(d.get("name", ""))
    if len(name) < 2:
        errors.append("Item name must be at least 2 characters.")
    elif len(name) > 100:
        errors.append("Item name exceeds maximum limit of 100 characters.")
    cleaned["name"] = name

    # 3. Category
    category = sanitize_string(d.get("category", "Other")) or "Other"
    cleaned["category"] = category

    # 4. Storage Location
    storage = sanitize_string(d.get("storage_location", "Pantry")) or "Pantry"
    cleaned["storage_location"] = storage

    # 5. Quantity
    try:
        qty = float(d.get("quantity", 0))
        if qty <= 0:
            errors.append("Quantity must be greater than zero.")
        elif qty > 100000:
            errors.append("Quantity exceeds maximum limit of 100,000.")
        cleaned["quantity"] = round(qty, 2)
    except (ValueError, TypeError):
        errors.append(f"Invalid numeric value for quantity: '{d.get('quantity')}'.")
        cleaned["quantity"] = 1.0

    # 6. Unit
    unit = sanitize_string(d.get("unit", "units")) or "units"
    cleaned["unit"] = unit

    # 7. Purchase Date
    p_str = sanitize_string(d.get("purchase_date", ""))
    if not p_str:
        p_date = date.today()
        cleaned["purchase_date"] = p_date.strftime("%Y-%m-%d")
    else:
        ok, p_date, err = validate_date_string(p_str)
        if not ok:
            errors.append(f"Purchase date error: {err}")
            cleaned["purchase_date"] = date.today().strftime("%Y-%m-%d")
        else:
            cleaned["purchase_date"] = p_date.strftime("%Y-%m-%d")

    # 8. Expiry Date
    e_str = sanitize_string(d.get("expiry_date", ""))
    if not e_str:
        errors.append("Expiry date is required.")
        cleaned["expiry_date"] = date.today().strftime("%Y-%m-%d")
    else:
        ok, e_date, err = validate_date_string(e_str)
        if not ok:
            errors.append(f"Expiry date error: {err}")
            cleaned["expiry_date"] = date.today().strftime("%Y-%m-%d")
        else:
            cleaned["expiry_date"] = e_date.strftime("%Y-%m-%d")
            # Logic check: Expiry date vs Purchase date
            if p_date and e_date < p_date:
                # Warning or soft error: allow but note or flag
                pass

    # 9. Unit Cost
    try:
        cost = float(d.get("unit_cost", 0.0))
        if cost < 0:
            errors.append("Unit cost cannot be negative.")
        elif cost > 100000:
            errors.append("Unit cost exceeds realistic ceiling ($100,000).")
        cleaned["unit_cost"] = round(cost, 2)
    except (ValueError, TypeError):
        errors.append(f"Invalid numeric value for unit cost: '{d.get('unit_cost')}'.")
        cleaned["unit_cost"] = 0.0

    # 10. Notes
    cleaned["notes"] = sanitize_string(d.get("notes", ""))
    cleaned["added_at"] = sanitize_string(d.get("added_at", datetime.now().isoformat()))

    return (len(errors) == 0, cleaned, errors)


# ==========================================
# Terminal Prompt Wrappers with Retry Loops
# ==========================================

def prompt_string(prompt: str, min_len: int = 1, max_len: int = 500, default: Optional[str] = None) -> str:
    """Prompt for a non-blank string within bounds, retrying on invalid entry."""
    while True:
        def_hint = f" [{default}]" if default is not None else ""
        raw = input(f"{prompt}{def_hint}: ").strip()
        if not raw and default is not None:
            return default
        cleaned = sanitize_string(raw)
        if len(cleaned) < min_len:
            print(f"{ANSI_RED}✕ Input must be at least {min_len} character(s). Please try again.{ANSI_RESET}")
            continue
        if len(cleaned) > max_len:
            print(f"{ANSI_RED}✕ Input exceeds max length of {max_len} characters. Please try again.{ANSI_RESET}")
            continue
        return cleaned


def prompt_float(prompt: str, min_val: float = 0.0, max_val: float = 100000.0, default: Optional[float] = None) -> float:
    """Prompt for a float within range, retrying defensively."""
    while True:
        def_hint = f" [{default}]" if default is not None else ""
        raw = input(f"{prompt}{def_hint}: ").strip()
        if not raw and default is not None:
            return default
        try:
            val = float(raw)
            if val < min_val:
                print(f"{ANSI_RED}✕ Value cannot be less than {min_val}. Please try again.{ANSI_RESET}")
                continue
            if val > max_val:
                print(f"{ANSI_RED}✕ Value cannot exceed {max_val}. Please try again.{ANSI_RESET}")
                continue
            return round(val, 2)
        except ValueError:
            print(f"{ANSI_RED}✕ Invalid numeric entry '{raw}'. Please enter a valid number.{ANSI_RESET}")


def prompt_int(prompt: str, min_val: int = 0, max_val: int = 10000, default: Optional[int] = None) -> int:
    """Prompt for an integer within range, retrying defensively."""
    while True:
        def_hint = f" [{default}]" if default is not None else ""
        raw = input(f"{prompt}{def_hint}: ").strip()
        if not raw and default is not None:
            return default
        try:
            val = int(raw)
            if val < min_val or val > max_val:
                print(f"{ANSI_RED}✕ Value must be between {min_val} and {max_val}.{ANSI_RESET}")
                continue
            return val
        except ValueError:
            print(f"{ANSI_RED}✕ Invalid integer '{raw}'. Please enter a whole number.{ANSI_RESET}")


def prompt_date(prompt: str, default: Optional[str] = None) -> str:
    """Prompt for a valid date string (YYYY-MM-DD or shortcut), retrying defensively."""
    while True:
        def_hint = f" [{default}]" if default is not None else " (YYYY-MM-DD, 'today', '+3d')"
        raw = input(f"{prompt}{def_hint}: ").strip()
        if not raw and default is not None:
            ok, p_date, _ = validate_date_string(default)
            if ok and p_date:
                return p_date.strftime("%Y-%m-%d")
        ok, p_date, err = validate_date_string(raw)
        if ok and p_date:
            return p_date.strftime("%Y-%m-%d")
        print(f"{ANSI_RED}✕ {err}{ANSI_RESET}")


def prompt_choice(prompt: str, choices: List[str], default_idx: Optional[int] = 0) -> str:
    """Present a list of numbered choices and prompt user to select one."""
    print(f"\n{prompt}")
    for idx, opt in enumerate(choices, 1):
        def_mark = " (default)" if default_idx is not None and (idx - 1) == default_idx else ""
        print(f"  [{idx}] {opt}{def_mark}")
    
    while True:
        def_hint = f" [{default_idx + 1}]" if default_idx is not None else ""
        raw = input(f"Select option (1-{len(choices)}){def_hint}: ").strip()
        if not raw and default_idx is not None:
            return choices[default_idx]
        try:
            choice_num = int(raw)
            if 1 <= choice_num <= len(choices):
                return choices[choice_num - 1]
            print(f"{ANSI_RED}✕ Number must be between 1 and {len(choices)}.{ANSI_RESET}")
        except ValueError:
            # Check if user typed the name directly
            matched = [c for c in choices if c.lower() == raw.lower()]
            if matched:
                return matched[0]
            print(f"{ANSI_RED}✕ Invalid selection. Enter the choice number.{ANSI_RESET}")


def prompt_confirm(prompt: str, default: bool = True) -> bool:
    """Prompt for Yes/No confirmation."""
    hint = " [Y/n]" if default else " [y/N]"
    while True:
        raw = input(f"{prompt}{hint}: ").strip().lower()
        if not raw:
            return default
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print(f"{ANSI_RED}✕ Please enter 'y' for yes or 'n' for no.{ANSI_RESET}")
