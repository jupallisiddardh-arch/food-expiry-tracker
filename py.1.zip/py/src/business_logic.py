"""Core Business Logic Engine for Food Expiry Tracker.

Contains computational algorithms to analyze pantry items, compute shelf life,
calculate monetary waste risk, prioritize consumption, and flag threshold anomalies.
"""

from datetime import datetime, date
from typing import List, Dict, Any, Optional, Tuple
from src.models import FoodItem, ExpiryStatus


def calculate_days_remaining(expiry_date_str: str, ref_date: Optional[date] = None) -> int:
    """Calculate days until expiry. Negative implies overdue/expired."""
    if ref_date is None:
        ref_date = date.today()
    try:
        exp = datetime.strptime(expiry_date_str.strip(), "%Y-%m-%d").date()
        return (exp - ref_date).days
    except (ValueError, TypeError):
        return 0


def get_expiry_status(days: int) -> ExpiryStatus:
    """Classify status indicator based on remaining shelf days."""
    if days < 0:
        return ExpiryStatus.EXPIRED
    elif days <= 3:
        return ExpiryStatus.CRITICAL
    elif days <= 7:
        return ExpiryStatus.EXPIRING_SOON
    else:
        return ExpiryStatus.SAFE


def rank_consumption_priority(items: List[FoodItem], ref_date: Optional[date] = None) -> List[FoodItem]:
    """
    Sort items by consumption priority:
    1. Expiring soonest (lowest days remaining first, including expired).
    2. Within equal days, higher total cost/value first (prevent higher economic waste).
    """
    return sorted(
        items,
        key=lambda item: (item.days_remaining(ref_date), -item.total_cost)
    )


def compute_waste_risk(items: List[FoodItem], days_window: int = 3, ref_date: Optional[date] = None) -> Dict[str, Any]:
    """
    Compute immediate financial and physical waste risk within a threshold window.
    Default threshold: items already expired or expiring within 3 days.
    """
    if ref_date is None:
        ref_date = date.today()

    expired_items = [it for it in items if it.days_remaining(ref_date) < 0]
    critical_items = [it for it in items if 0 <= it.days_remaining(ref_date) <= days_window]

    expired_cost = sum(it.total_cost for it in expired_items)
    critical_cost = sum(it.total_cost for it in critical_items)
    total_inventory_cost = sum(it.total_cost for it in items)

    risk_percentage = 0.0
    if total_inventory_cost > 0:
        risk_percentage = round(((expired_cost + critical_cost) / total_inventory_cost) * 100, 2)

    return {
        "expired_count": len(expired_items),
        "expired_cost": round(expired_cost, 2),
        "critical_count": len(critical_items),
        "critical_cost": round(critical_cost, 2),
        "total_at_risk_cost": round(expired_cost + critical_cost, 2),
        "total_inventory_cost": round(total_inventory_cost, 2),
        "risk_percentage": risk_percentage,
        "critical_items": critical_items,
        "expired_items": expired_items,
    }


def generate_threshold_warnings(items: List[FoodItem], urgent_days: int = 3, warning_days: int = 7, ref_date: Optional[date] = None) -> List[Dict[str, Any]]:
    """
    Automated console warning flags highlighting overdue deadlines, critical limit breaches,
    and urgent actions required.
    """
    if ref_date is None:
        ref_date = date.today()

    warnings: List[Dict[str, Any]] = []

    expired = [it for it in items if it.days_remaining(ref_date) < 0]
    if expired:
        warnings.append({
            "level": "CRITICAL_ALERT",
            "code": "OVERDUE_EXPIRED",
            "count": len(expired),
            "message": f"🚨 {len(expired)} item(s) are EXPIRED and may pose food safety hazards!",
            "items": expired,
        })

    critical = [it for it in items if 0 <= it.days_remaining(ref_date) <= urgent_days]
    if critical:
        warnings.append({
            "level": "URGENT_WARNING",
            "code": "EXPIRING_URGENT",
            "count": len(critical),
            "message": f"⚠️  {len(critical)} item(s) expire within {urgent_days} days! Prioritize consumption.",
            "items": critical,
        })

    nearing = [it for it in items if urgent_days < it.days_remaining(ref_date) <= warning_days]
    if nearing:
        warnings.append({
            "level": "NOTICE",
            "code": "EXPIRING_SOON",
            "count": len(nearing),
            "message": f"ℹ️  {len(nearing)} item(s) expire within {warning_days} days. Plan meals accordingly.",
            "items": nearing,
        })

    return warnings


def detect_anomalies(items: List[FoodItem]) -> List[Dict[str, Any]]:
    """
    Detect data anomalies such as:
    - Purchase date after expiry date.
    - Extreme expiry dates (> 10 years in future or < 5 years in past).
    - Unusually high unit cost (> $500).
    - Quantity <= 0.
    """
    anomalies: List[Dict[str, Any]] = []
    today = date.today()

    for it in items:
        # Check purchase vs expiry date
        try:
            p_date = datetime.strptime(it.purchase_date, "%Y-%m-%d").date()
            e_date = datetime.strptime(it.expiry_date, "%Y-%m-%d").date()
            if p_date > e_date:
                anomalies.append({
                    "item_id": it.id,
                    "item_name": it.name,
                    "type": "DATE_INCONSISTENCY",
                    "description": f"Purchase date ({it.purchase_date}) is after Expiry date ({it.expiry_date})."
                })
            if (e_date - today).days > 3650:
                anomalies.append({
                    "item_id": it.id,
                    "item_name": it.name,
                    "type": "FAR_FUTURE_EXPIRY",
                    "description": f"Expiry date ({it.expiry_date}) is over 10 years in the future."
                })
        except (ValueError, TypeError):
            pass

        if it.unit_cost > 500:
            anomalies.append({
                "item_id": it.id,
                "item_name": it.name,
                "type": "HIGH_UNIT_COST",
                "description": f"Unit cost (${it.unit_cost}) is unusually high."
            })
        if it.quantity <= 0:
            anomalies.append({
                "item_id": it.id,
                "item_name": it.name,
                "type": "ZERO_OR_NEGATIVE_QUANTITY",
                "description": f"Item quantity is {it.quantity}."
            })

    return anomalies
