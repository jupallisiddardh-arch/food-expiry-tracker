"""Executive Summary and Analytics Engine.

Computes totals, averages, status distributions, storage patterns,
and financial waste risk. Supports optional Pandas acceleration when installed.
"""

from typing import List, Dict, Any, Optional
from datetime import date
from collections import defaultdict

from src.models import FoodItem, ExpiryStatus


def generate_executive_summary(items: List[FoodItem], ref_date: Optional[date] = None) -> Dict[str, Any]:
    """
    Generate comprehensive aggregation metrics:
      - Totals (items, quantity, valuation)
      - Averages (average cost, average shelf life)
      - Status distribution (Expired, Critical, Expiring Soon, Safe)
      - Category & storage location breakdowns
      - Waste risk analysis
    """
    if ref_date is None:
        ref_date = date.today()

    total_count = len(items)
    if total_count == 0:
        return {
            "total_items": 0,
            "total_quantity": 0.0,
            "total_value": 0.0,
            "average_item_cost": 0.0,
            "average_days_remaining": 0.0,
            "status_counts": {s.value: 0 for s in ExpiryStatus},
            "status_percentages": {s.value: 0.0 for s in ExpiryStatus},
            "category_breakdown": {},
            "storage_breakdown": {},
            "waste_risk": {
                "expired_count": 0,
                "expired_cost": 0.0,
                "critical_count": 0,
                "critical_cost": 0.0,
                "at_risk_value": 0.0,
                "risk_percentage": 0.0
            },
            "urgent_items": []
        }

    total_quantity = sum(item.quantity for item in items)
    total_value = sum(item.total_cost for item in items)
    avg_item_cost = total_value / total_count if total_count > 0 else 0.0

    days_list = [item.days_remaining(ref_date) for item in items]
    avg_days_remaining = sum(days_list) / total_count if total_count > 0 else 0.0

    # Status distribution
    status_counts = {s.value: 0 for s in ExpiryStatus}
    for item in items:
        status_counts[item.status(ref_date).value] += 1

    status_percentages = {
        s: round((count / total_count) * 100, 1)
        for s, count in status_counts.items()
    }

    # Category breakdown
    category_data = defaultdict(lambda: {"count": 0, "quantity": 0.0, "value": 0.0})
    for item in items:
        c = item.category or "Other"
        category_data[c]["count"] += 1
        category_data[c]["quantity"] += item.quantity
        category_data[c]["value"] += item.total_cost

    category_breakdown = {}
    for cat, data in category_data.items():
        category_breakdown[cat] = {
            "count": data["count"],
            "quantity": round(data["quantity"], 2),
            "value": round(data["value"], 2),
            "percent_of_total": round((data["count"] / total_count) * 100, 1)
        }

    # Storage breakdown
    storage_data = defaultdict(lambda: {"count": 0, "quantity": 0.0, "value": 0.0})
    for item in items:
        loc = item.storage_location or "Pantry"
        storage_data[loc]["count"] += 1
        storage_data[loc]["quantity"] += item.quantity
        storage_data[loc]["value"] += item.total_cost

    storage_breakdown = {}
    for loc, data in storage_data.items():
        storage_breakdown[loc] = {
            "count": data["count"],
            "quantity": round(data["quantity"], 2),
            "value": round(data["value"], 2),
            "percent_of_total": round((data["count"] / total_count) * 100, 1)
        }

    # Waste Risk calculation
    expired_items = [it for it in items if it.days_remaining(ref_date) < 0]
    critical_items = [it for it in items if 0 <= it.days_remaining(ref_date) <= 3]
    expired_cost = sum(it.total_cost for it in expired_items)
    critical_cost = sum(it.total_cost for it in critical_items)
    at_risk_value = expired_cost + critical_cost
    risk_percentage = round((at_risk_value / total_value * 100), 1) if total_value > 0 else 0.0

    # Top items needing urgent consumption
    urgent_ranked = sorted(
        [it for it in items if it.days_remaining(ref_date) <= 7],
        key=lambda it: (it.days_remaining(ref_date), -it.total_cost)
    )

    return {
        "total_items": total_count,
        "total_quantity": round(total_quantity, 2),
        "total_value": round(total_value, 2),
        "average_item_cost": round(avg_item_cost, 2),
        "average_days_remaining": round(avg_days_remaining, 1),
        "status_counts": status_counts,
        "status_percentages": status_percentages,
        "category_breakdown": category_breakdown,
        "storage_breakdown": storage_breakdown,
        "waste_risk": {
            "expired_count": len(expired_items),
            "expired_cost": round(expired_cost, 2),
            "critical_count": len(critical_items),
            "critical_cost": round(critical_cost, 2),
            "at_risk_value": round(at_risk_value, 2),
            "risk_percentage": risk_percentage
        },
        "urgent_items": [it.to_dict() for it in urgent_ranked[:10]]
    }


def to_pandas_dataframe(items: List[FoodItem]):
    """
    Attempt to convert items to a pandas DataFrame if pandas is installed.
    Returns DataFrame or None if pandas is not available.
    """
    try:
        import pandas as pd
        records = [item.to_dict() for item in items]
        df = pd.DataFrame(records)
        return df
    except ImportError:
        return None
