"""Data models representing Food Expiry Tracker records and operational states."""

from dataclasses import dataclass, asdict, field
from datetime import datetime, date
from enum import Enum
from typing import Optional, Dict, Any


class FoodCategory(str, Enum):
    DAIRY = "Dairy"
    PRODUCE = "Produce"
    MEAT_POULTRY = "Meat & Poultry"
    SEAFOOD = "Seafood"
    BAKERY = "Bakery"
    GRAINS_PASTA = "Grains & Pasta"
    CANNED_GOODS = "Canned Goods"
    BEVERAGES = "Beverages"
    CONDIMENTS = "Condiments & Sauces"
    SNACKS = "Snacks & Sweets"
    FROZEN = "Frozen Foods"
    OTHER = "Other"

    @classmethod
    def list_all(cls):
        return [c.value for c in cls]


class StorageLocation(str, Enum):
    PANTRY = "Pantry"
    FRIDGE = "Fridge"
    FREEZER = "Freezer"
    COUNTERTOP = "Countertop"

    @classmethod
    def list_all(cls):
        return [loc.value for loc in cls]


class ExpiryStatus(str, Enum):
    EXPIRED = "Expired"
    CRITICAL = "Critical (<=3 Days)"
    EXPIRING_SOON = "Expiring Soon (4-7 Days)"
    SAFE = "Safe / Fresh (>7 Days)"


@dataclass
class FoodItem:
    id: str
    name: str
    category: str
    storage_location: str
    quantity: float
    unit: str
    purchase_date: str  # YYYY-MM-DD
    expiry_date: str    # YYYY-MM-DD
    unit_cost: float = 0.0  # Monetary value per unit
    notes: str = ""
    added_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def days_remaining(self, ref_date: Optional[date] = None) -> int:
        """Calculate days remaining until expiry from reference date (defaults to today)."""
        if ref_date is None:
            ref_date = date.today()
        try:
            exp = datetime.strptime(self.expiry_date.strip(), "%Y-%m-%d").date()
            return (exp - ref_date).days
        except (ValueError, TypeError):
            return 0

    def status(self, ref_date: Optional[date] = None) -> ExpiryStatus:
        """Evaluate status category based on days remaining."""
        days = self.days_remaining(ref_date)
        if days < 0:
            return ExpiryStatus.EXPIRED
        elif days <= 3:
            return ExpiryStatus.CRITICAL
        elif days <= 7:
            return ExpiryStatus.EXPIRING_SOON
        else:
            return ExpiryStatus.SAFE

    @property
    def total_cost(self) -> float:
        """Total monetary value of this food inventory entry."""
        return round(float(self.quantity) * float(self.unit_cost), 2)

    @property
    def is_expired(self) -> bool:
        return self.days_remaining() < 0

    @property
    def is_urgent(self) -> bool:
        days = self.days_remaining()
        return 0 <= days <= 3

    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON-serializable dictionary."""
        data = asdict(self)
        # Append calculated attributes for reporting/convenience
        data["days_remaining"] = self.days_remaining()
        data["status"] = self.status().value
        data["total_cost"] = self.total_cost
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FoodItem":
        """Instantiate FoodItem from dictionary, ignoring extra computed fields."""
        valid_keys = {
            "id", "name", "category", "storage_location",
            "quantity", "unit", "purchase_date", "expiry_date",
            "unit_cost", "notes", "added_at"
        }
        filtered = {k: v for k, v in data.items() if k in valid_keys}
        # Cast numerical fields safely
        if "quantity" in filtered:
            filtered["quantity"] = float(filtered["quantity"])
        if "unit_cost" in filtered:
            filtered["unit_cost"] = float(filtered["unit_cost"])
        return cls(**filtered)
