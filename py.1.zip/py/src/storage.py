"""Local data persistence engine for CSV and JSON formats.

Guarantees data survives program restarts, handles corrupted/missing files gracefully,
and supports bulk dataset imports with detailed row-by-row error logging.
"""

import os
import csv
import json
import shutil
from datetime import datetime
from typing import List, Tuple, Dict, Any, Optional

from src.models import FoodItem
from src.validation import validate_food_item_dict

CSV_FIELDNAMES = [
    "id",
    "name",
    "category",
    "storage_location",
    "quantity",
    "unit",
    "purchase_date",
    "expiry_date",
    "unit_cost",
    "notes",
    "added_at"
]


class StorageManager:
    """Manages persistent reading and writing to JSON and CSV files."""

    def __init__(self, json_path: str = "data/inventory.json", csv_path: str = "data/inventory.csv"):
        self.json_path = json_path
        self.csv_path = csv_path
        self._ensure_directories()

    def _ensure_directories(self):
        """Ensure parent directory of storage files exists."""
        for path in (self.json_path, self.csv_path):
            directory = os.path.dirname(path)
            if directory and not os.path.exists(directory):
                os.makedirs(directory, exist_ok=True)

    def _backup_corrupt_file(self, file_path: str) -> str:
        """Create a safety backup of a corrupted file before re-initialization."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = f"{file_path}.corrupt_{timestamp}.bak"
        try:
            shutil.copyfile(file_path, backup_path)
            return backup_path
        except Exception:
            return ""

    # ==========================
    # JSON Persistence
    # ==========================

    def load_from_json(self) -> Tuple[List[FoodItem], List[str]]:
        """
        Load FoodItems from JSON file.
        Detects FileNotFoundError, json.JSONDecodeError, or schema violations.
        Returns (items, warning_messages).
        """
        warnings: List[str] = []
        if not os.path.exists(self.json_path):
            # Auto-initialize clean empty file
            self.save_to_json([])
            warnings.append(f"Storage file '{self.json_path}' not found. Initialized new empty database.")
            return [], warnings

        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    self.save_to_json([])
                    warnings.append(f"Empty storage file '{self.json_path}'. Re-initialized with clean template.")
                    return [], warnings
                data = json.loads(content)

            if not isinstance(data, list):
                bak = self._backup_corrupt_file(self.json_path)
                self.save_to_json([])
                warnings.append(f"Corrupt JSON schema (expected list). Backed up to '{bak}' and re-initialized.")
                return [], warnings

            items: List[FoodItem] = []
            for idx, raw_record in enumerate(data):
                if not isinstance(raw_record, dict):
                    warnings.append(f"Skipping record #{idx + 1}: expected dictionary, got {type(raw_record).__name__}.")
                    continue
                is_valid, cleaned, errors = validate_food_item_dict(raw_record)
                if is_valid:
                    items.append(FoodItem.from_dict(cleaned))
                else:
                    warnings.append(f"Invalid record #{idx + 1} ('{raw_record.get('name', 'unknown')}'): {'; '.join(errors)}")

            return items, warnings

        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            bak = self._backup_corrupt_file(self.json_path)
            self.save_to_json([])
            warnings.append(f"Corrupted JSON detected ({str(e)}). Preserved backup at '{bak}'. Initialized fresh database.")
            return [], warnings
        except Exception as e:
            warnings.append(f"Unexpected error loading JSON: {str(e)}")
            return [], warnings

    def save_to_json(self, items: List[FoodItem]) -> bool:
        """Safely serialize FoodItems to JSON using an atomic write."""
        self._ensure_directories()
        temp_path = f"{self.json_path}.tmp"
        try:
            records = [item.to_dict() for item in items]
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(records, f, indent=2, ensure_ascii=False)
            
            # Atomic replace
            if os.path.exists(self.json_path):
                os.replace(temp_path, self.json_path)
            else:
                os.rename(temp_path, self.json_path)
            return True
        except Exception as e:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise IOError(f"Failed to save JSON data: {e}")

    # ==========================
    # CSV Persistence
    # ==========================

    def load_from_csv(self, filepath: Optional[str] = None) -> Tuple[List[FoodItem], List[str]]:
        """
        Load FoodItems from structured CSV file.
        Returns (items, warning_messages).
        """
        path = filepath or self.csv_path
        warnings: List[str] = []

        if not os.path.exists(path):
            if path == self.csv_path:
                self.save_to_csv([], path)
                warnings.append(f"CSV file '{path}' was missing. Initialized empty template.")
            else:
                warnings.append(f"Specified CSV file '{path}' does not exist.")
            return [], warnings

        try:
            items: List[FoodItem] = []
            with open(path, "r", encoding="utf-8", newline="") as f:
                reader = csv.DictReader(f)
                if not reader.fieldnames:
                    warnings.append(f"CSV file '{path}' is blank.")
                    return [], warnings

                for row_num, row in enumerate(reader, start=2):
                    is_valid, cleaned, errors = validate_food_item_dict(row)
                    if is_valid:
                        items.append(FoodItem.from_dict(cleaned))
                    else:
                        warnings.append(f"Line {row_num} invalid ({row.get('name', 'unnamed')}): {', '.join(errors)}")

            return items, warnings

        except Exception as e:
            warnings.append(f"Failed to read CSV '{path}': {str(e)}")
            return [], warnings

    def save_to_csv(self, items: List[FoodItem], filepath: Optional[str] = None) -> bool:
        """Safely write FoodItems to CSV."""
        path = filepath or self.csv_path
        directory = os.path.dirname(path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)

        temp_path = f"{path}.tmp"
        try:
            with open(temp_path, "w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=CSV_FIELDNAMES)
                writer.writeheader()
                for item in items:
                    raw_dict = item.to_dict()
                    row = {k: raw_dict.get(k, "") for k in CSV_FIELDNAMES}
                    writer.writerow(row)

            if os.path.exists(path):
                os.replace(temp_path, path)
            else:
                os.rename(temp_path, path)
            return True
        except Exception as e:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise IOError(f"Failed to save CSV data: {e}")

    # ==========================
    # Bulk Dataset Import
    # ==========================

    def import_bulk_dataset(self, import_filepath: str) -> Dict[str, Any]:
        """
        Ingest legacy or external CSV/JSON dataset with automatic format validation
        and detailed row-by-row error logs.
        """
        result = {
            "success": False,
            "total_rows_read": 0,
            "valid_imported_items": [],
            "error_log": [],
            "filepath": import_filepath
        }

        if not os.path.exists(import_filepath):
            result["error_log"].append(f"File not found: '{import_filepath}'")
            return result

        ext = os.path.splitext(import_filepath)[1].lower()

        try:
            if ext == ".json":
                with open(import_filepath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if not isinstance(data, list):
                    result["error_log"].append("JSON dataset root must be an array/list of items.")
                    return result
                result["total_rows_read"] = len(data)
                for idx, row in enumerate(data, start=1):
                    is_valid, cleaned, errors = validate_food_item_dict(row)
                    if is_valid:
                        result["valid_imported_items"].append(FoodItem.from_dict(cleaned))
                    else:
                        result["error_log"].append(f"Record #{idx} error: {'; '.join(errors)}")
            else:
                # Assume CSV
                with open(import_filepath, "r", encoding="utf-8", newline="") as f:
                    reader = csv.DictReader(f)
                    if not reader.fieldnames:
                        result["error_log"].append("CSV has no header row or is empty.")
                        return result
                    
                    rows = list(reader)
                    result["total_rows_read"] = len(rows)
                    for row_num, row in enumerate(rows, start=2):
                        is_valid, cleaned, errors = validate_food_item_dict(row)
                        if is_valid:
                            result["valid_imported_items"].append(FoodItem.from_dict(cleaned))
                        else:
                            result["error_log"].append(f"Row {row_num} ('{row.get('name', 'unnamed')}'): {'; '.join(errors)}")

            result["success"] = True
            return result

        except Exception as e:
            result["error_log"].append(f"Fatal parsing error: {str(e)}")
            return result
