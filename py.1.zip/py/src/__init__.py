"""Food Expiry Tracker - StudentLife Hack
Core Package Initialization
"""

__version__ = "1.0.0"
__author__ = "StudentLife Hack Team"
