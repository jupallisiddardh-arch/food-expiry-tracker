"""Interactive Terminal Interface (CLI) for Food Expiry Tracker.

Features menu-driven command prompt, ANSI color badges, automated threshold warnings,
pagination for large datasets, and defensive input validation.
"""

import os
import sys
from datetime import date
from typing import List, Optional

from src.models import FoodItem, FoodCategory, StorageLocation, ExpiryStatus
from src.storage import StorageManager
from src.validation import (
    prompt_string, prompt_float, prompt_int, prompt_date,
    prompt_choice, prompt_confirm, ANSI_RED, ANSI_GREEN,
    ANSI_YELLOW, ANSI_CYAN, ANSI_RESET
)
from src.business_logic import (
    generate_threshold_warnings, detect_anomalies, rank_consumption_priority
)
from src.search_filter import (
    search_by_keyword, filter_by_category, filter_by_storage,
    filter_by_status, sort_items
)
from src.analytics import generate_executive_summary
from src.visualizer import (
    format_table, render_ascii_bar_chart, render_matplotlib_charts,
    get_status_badge, ANSI_BOLD, ANSI_DIM
)
from src.exporter import ReportExporter


BANNER = f"""
{ANSI_CYAN}========================================================================================
   ___             _   ___            _               _____             _             
  / __|___  ___  __| | | __|_ ___ __ (_)_ _ _  _     |_   _| _ __ _  __| |_____ _ _   
 | (__/ _ \\/ _ \\/ _` | | _|| \\ \\ / '_ \\| | '_| || |      | || '_/ _` |/ _| / / -_) '_|  
  \\___\\___/\\___/\\__,_| |___|__/_\\_\\ .__/|_|_|  \\_, |      |_||_| \\__,_|\\__|_\\_\\___|_|    
                                  |_|         |__/                                    
{ANSI_YELLOW}      Project #62 | Domain: Food & Agriculture | StudentLife Hackathon Edition{ANSI_RESET}
========================================================================================
"""


class ExpiryTrackerCLI:
    """Terminal command interface orchestrator."""

    def __init__(self, json_path: str = "data/inventory.json", csv_path: str = "data/inventory.csv"):
        self.storage = StorageManager(json_path=json_path, csv_path=csv_path)
        self.exporter = ReportExporter(output_dir="exports")
        self.items: List[FoodItem] = []
        self._load_data()

    def _load_data(self):
        """Load inventory from JSON, fallback to CSV if empty or newly initialized."""
        items, warnings = self.storage.load_from_json()
        if not items and os.path.exists(self.storage.csv_path):
            csv_items, csv_warnings = self.storage.load_from_csv()
            if csv_items:
                items = csv_items
                self.storage.save_to_json(items)
        self.items = items
        for w in warnings:
            print(f"{ANSI_YELLOW}Notice: {w}{ANSI_RESET}")

    def _save_data(self):
        """Synchronize both JSON and CSV files."""
        self.storage.save_to_json(self.items)
        self.storage.save_to_csv(self.items)

    def display_alerts_banner(self):
        """Display immediate visual alerts for overdue or critical items."""
        warnings = generate_threshold_warnings(self.items)
        if not warnings:
            print(f"{ANSI_GREEN}✅ All pantry items are currently fresh and within safe dates.{ANSI_RESET}\n")
            return

        print(f"{ANSI_BOLD}--- ACTIVE PANTRY ALERTS ---{ANSI_RESET}")
        for w in warnings:
            if w["level"] == "CRITICAL_ALERT":
                print(f"{ANSI_RED}{w['message']}{ANSI_RESET}")
            elif w["level"] == "URGENT_WARNING":
                print(f"{ANSI_YELLOW}{w['message']}{ANSI_RESET}")
            else:
                print(f"{ANSI_CYAN}{w['message']}{ANSI_RESET}")
        print()

    def run(self):
        """Primary navigation dispatch loop."""
        print(BANNER)
        self.display_alerts_banner()

        while True:
            self._print_main_menu()
            choice = input(f"{ANSI_BOLD}Enter menu choice (0-9): {ANSI_RESET}").strip()

            if choice == "1":
                self.view_inventory_paged(self.items)
            elif choice == "2":
                self.add_item_interactive()
            elif choice == "3":
                self.search_and_filter_flow()
            elif choice == "4":
                self.view_analytics_dashboard()
            elif choice == "5":
                self.view_threshold_warnings_and_anomalies()
            elif choice == "6":
                self.export_reports_flow()
            elif choice == "7":
                self.bulk_import_flow()
            elif choice == "8":
                self.edit_or_delete_flow()
            elif choice == "9":
                self.launch_gui()
            elif choice == "0":
                print(f"\n{ANSI_GREEN}Saving records and shutting down Food Expiry Tracker. Stay fresh! 🥗{ANSI_RESET}\n")
                self._save_data()
                break
            else:
                print(f"{ANSI_RED}✕ Invalid option '{choice}'. Please select between 0 and 9.{ANSI_RESET}")

    def _print_main_menu(self):
        """Render clean menu choices with summary count."""
        expired_count = sum(1 for it in self.items if it.is_expired)
        urgent_count = sum(1 for it in self.items if it.is_urgent)
        badge = ""
        if expired_count > 0:
            badge += f" {ANSI_RED}[{expired_count} EXPIRED]{ANSI_RESET}"
        if urgent_count > 0:
            badge += f" {ANSI_YELLOW}[{urgent_count} URGENT]{ANSI_RESET}"

        print(f"\n{ANSI_BOLD}=== MAIN WORKFLOW MENU (Total Items: {len(self.items)}){badge} ==={ANSI_RESET}")
        print(f"  [{ANSI_CYAN}1{ANSI_RESET}] 📋 View Pantry Inventory (Paged Table & Status Badges)")
        print(f"  [{ANSI_CYAN}2{ANSI_RESET}] ➕ Add New Food Item (Defensive Input Validation)")
        print(f"  [{ANSI_CYAN}3{ANSI_RESET}] 🔍 Search & Multi-Criteria Filtering")
        print(f"  [{ANSI_CYAN}4{ANSI_RESET}] 📊 Executive Analytics & Waste Risk Dashboard")
        print(f"  [{ANSI_CYAN}5{ANSI_RESET}] ⚠️  Threshold Warning Indicators & Anomaly Audit")
        print(f"  [{ANSI_CYAN}6{ANSI_RESET}] 📁 Multi-Format Report Export (Markdown, CSV, TXT, JSON)")
        print(f"  [{ANSI_CYAN}7{ANSI_RESET}] 📥 Bulk Dataset Import (CSV/JSON with Error Log)")
        print(f"  [{ANSI_CYAN}8{ANSI_RESET}] ✏️  Edit or Delete Existing Pantry Item")
        print(f"  [{ANSI_CYAN}9{ANSI_RESET}] 🖥️  Launch Graphical User Interface (Tkinter GUI)")
        print(f"  [{ANSI_CYAN}0{ANSI_RESET}] 🚪 Save & Exit Application")

    # ==========================================
    # Feature 1: Paged Table View
    # ==========================================

    def view_inventory_paged(self, items_to_display: List[FoodItem]):
        """Render paginated terminal table with interactive page controls."""
        if not items_to_display:
            print(f"\n{ANSI_YELLOW}Notice: Inventory list is currently empty.{ANSI_RESET}")
            return

        page = 1
        page_size = 10
        sorted_list = sort_items(items_to_display, sort_by="expiry", ascending=True)

        while True:
            table_str, curr_page, total_pages = format_table(sorted_list, page=page, page_size=page_size)
            print("\n" + table_str)

            if total_pages <= 1:
                input(f"\n{ANSI_DIM}Press [Enter] to return to menu...{ANSI_RESET}")
                break

            prompt_msg = f"{ANSI_BOLD}[N]ext | [P]rev | [G]oto page | [S]ort | [Q]uit to menu: {ANSI_RESET}"
            nav = input(prompt_msg).strip().lower()

            if nav in ("n", "next"):
                if curr_page < total_pages:
                    page += 1
                else:
                    print(f"{ANSI_YELLOW}Already on the last page.{ANSI_RESET}")
            elif nav in ("p", "prev"):
                if curr_page > 1:
                    page -= 1
                else:
                    print(f"{ANSI_YELLOW}Already on the first page.{ANSI_RESET}")
            elif nav in ("g", "goto"):
                target = prompt_int("Enter page number", min_val=1, max_val=total_pages, default=curr_page)
                page = target
            elif nav in ("s", "sort"):
                sort_choice = prompt_choice("Sort by attribute:", ["expiry", "name", "category", "quantity", "cost"])
                asc = prompt_confirm("Ascending order?", default=True)
                sorted_list = sort_items(items_to_display, sort_by=sort_choice, ascending=asc)
                page = 1
            elif nav in ("q", "quit", ""):
                break

    # ==========================================
    # Feature 2: Defensive Input & Item Addition
    # ==========================================

    def add_item_interactive(self):
        """Guided workflow to record a new pantry item with strict defensive validation."""
        print(f"\n{ANSI_BOLD}--- ADD NEW PANTRY ITEM (Defensive Input Mode) ---{ANSI_RESET}")
        
        # Auto-generate next ID
        existing_ids = [it.id for it in self.items if it.id.startswith("ITEM-")]
        max_num = 0
        for i_id in existing_ids:
            try:
                num = int(i_id.split("-")[1])
                if num > max_num:
                    max_num = num
            except (IndexError, ValueError):
                pass
        suggested_id = f"ITEM-{max_num + 1:03d}"

        item_id = prompt_string("Item ID", min_len=2, max_len=20, default=suggested_id)
        # Check uniqueness
        if any(it.id == item_id for it in self.items):
            print(f"{ANSI_RED}✕ An item with ID '{item_id}' already exists! Aborting.{ANSI_RESET}")
            return

        name = prompt_string("Food Item Name (e.g. 'Greek Yogurt', 'Brown Rice')", min_len=2, max_len=60)
        
        # Category selection
        cat_choices = FoodCategory.list_all()
        category = prompt_choice("Select Food Category:", cat_choices, default_idx=0)

        # Storage location selection
        loc_choices = StorageLocation.list_all()
        storage = prompt_choice("Select Storage Location:", loc_choices, default_idx=1)

        # Quantity and unit
        quantity = prompt_float("Quantity (must be > 0)", min_val=0.01, max_val=10000.0, default=1.0)
        unit = prompt_string("Unit of measurement (e.g. units, kg, liters, cans, packs)", min_len=1, max_len=20, default="units")

        # Purchase date
        p_date = prompt_date("Purchase Date (YYYY-MM-DD or 'today')", default="today")

        # Expiry date
        print(f"{ANSI_DIM}Tip: You can type 'today', '+3d' (in 3 days), '+2w' (in 2 weeks), or 'YYYY-MM-DD'{ANSI_RESET}")
        e_date = prompt_date("Expiry Date")

        # Unit cost
        cost = prompt_float("Estimated Unit Cost ($)", min_val=0.0, max_val=5000.0, default=0.0)

        # Notes
        notes = input("Optional Notes (e.g. 'Organic', 'Opened'): ").strip()

        # Build and construct
        new_item = FoodItem(
            id=item_id,
            name=name,
            category=category,
            storage_location=storage,
            quantity=quantity,
            unit=unit,
            purchase_date=p_date,
            expiry_date=e_date,
            unit_cost=cost,
            notes=notes
        )

        self.items.append(new_item)
        self._save_data()

        status_str = get_status_badge(new_item)
        print(f"\n{ANSI_GREEN}✔ Successfully recorded '{new_item.name}' [{new_item.id}]!{ANSI_RESET}")
        print(f"  Status: {status_str} | Total Valuation: ${new_item.total_cost:.2f}")

    # ==========================================
    # Feature 3: Query & Multi-Criteria Search
    # ==========================================

    def search_and_filter_flow(self):
        """Search and filtering sub-menu."""
        print(f"\n{ANSI_BOLD}--- RECORD QUERY & SEARCH ENGINE ---{ANSI_RESET}")
        print("  [1] Keyword Search (Name, Notes, ID)")
        print("  [2] Filter by Category")
        print("  [3] Filter by Storage Location (Fridge, Pantry, Freezer)")
        print("  [4] Filter by Shelf Status (Expired, Critical, Expiring Soon, Safe)")
        print("  [5] Filter by Remaining Days Window (e.g. <= 3 days)")
        print("  [0] Return to Main Menu")

        sub_choice = input(f"{ANSI_BOLD}Select filter method (0-5): {ANSI_RESET}").strip()

        if sub_choice == "1":
            kw = prompt_string("Enter search keyword", min_len=1, max_len=200)
            results = search_by_keyword(self.items, kw)
            print(f"\n{ANSI_CYAN}Found {len(results)} item(s) matching keyword '{kw}':{ANSI_RESET}")
            self.view_inventory_paged(results)

        elif sub_choice == "2":
            cats = ["All"] + FoodCategory.list_all()
            selected = prompt_choice("Choose Category to filter by:", cats, default_idx=0)
            if selected == "All":
                self.view_inventory_paged(self.items)
            else:
                results = filter_by_category(self.items, selected)
                print(f"\n{ANSI_CYAN}Found {len(results)} item(s) in category '{selected}':{ANSI_RESET}")
                self.view_inventory_paged(results)

        elif sub_choice == "3":
            locs = ["All"] + StorageLocation.list_all()
            selected = prompt_choice("Choose Storage Location to filter by:", locs, default_idx=0)
            if selected == "All":
                self.view_inventory_paged(self.items)
            else:
                results = filter_by_storage(self.items, selected)
                print(f"\n{ANSI_CYAN}Found {len(results)} item(s) stored in '{selected}':{ANSI_RESET}")
                self.view_inventory_paged(results)

        elif sub_choice == "4":
            stat_options = [s.value for s in ExpiryStatus]
            chosen_stat_str = prompt_choice("Select Expiry Status:", stat_options)
            chosen_enum = next(s for s in ExpiryStatus if s.value == chosen_stat_str)
            results = filter_by_status(self.items, chosen_enum)
            print(f"\n{ANSI_CYAN}Found {len(results)} item(s) with status '{chosen_stat_str}':{ANSI_RESET}")
            self.view_inventory_paged(results)

        elif sub_choice == "5":
            max_d = prompt_int("Enter maximum days remaining (e.g. 3 for critical)", min_val=-1000, max_val=1000, default=3)
            results = [it for it in self.items if it.days_remaining() <= max_d]
            print(f"\n{ANSI_CYAN}Found {len(results)} item(s) with <= {max_d} days remaining:{ANSI_RESET}")
            self.view_inventory_paged(results)

    # ==========================================
    # Feature 4: Executive Summary Dashboard
    # ==========================================

    def view_analytics_dashboard(self):
        """Display executive totals, averages, status distributions, and waste risk."""
        summary = generate_executive_summary(self.items)
        print(f"\n{ANSI_BOLD}======================================================{ANSI_RESET}")
        print(f"{ANSI_BOLD}           EXECUTIVE PANTRY ANALYTICS DASHBOARD       {ANSI_RESET}")
        print(f"{ANSI_BOLD}======================================================{ANSI_RESET}")

        print(f"\n{ANSI_BOLD}1. CORE METRICS & PORTFOLIO VALUATION:{ANSI_RESET}")
        print(f"  • Total Tracked Items:    {ANSI_CYAN}{summary['total_items']}{ANSI_RESET} records")
        print(f"  • Total Physical Units:   {ANSI_CYAN}{summary['total_quantity']}{ANSI_RESET} units")
        print(f"  • Total Inventory Value:  {ANSI_GREEN}${summary['total_value']:.2f}{ANSI_RESET}")
        print(f"  • Average Cost per Item:  ${summary['average_item_cost']:.2f}")
        print(f"  • Average Shelf Life:     {summary['average_days_remaining']} days")

        print(f"\n{ANSI_BOLD}2. ECONOMIC WASTE RISK ANALYSIS:{ANSI_RESET}")
        wr = summary["waste_risk"]
        print(f"  • Expired Value Loss:     {ANSI_RED}${wr['expired_cost']:.2f} ({wr['expired_count']} items){ANSI_RESET}")
        print(f"  • Critical (≤3d) Risk:    {ANSI_YELLOW}${wr['critical_cost']:.2f} ({wr['critical_count']} items){ANSI_RESET}")
        print(f"  • Total Value at Risk:    {ANSI_BOLD}${wr['at_risk_value']:.2f} ({wr['risk_percentage']}% of pantry){ANSI_RESET}")

        # ASCII Chart for Status
        status_chart = render_ascii_bar_chart("3. EXPIRY STATUS DISTRIBUTION", summary["status_counts"], total=summary["total_items"])
        print(status_chart)

        # ASCII Chart for Storage
        storage_counts = {loc: data["count"] for loc, data in summary["storage_breakdown"].items()}
        storage_chart = render_ascii_bar_chart("4. STORAGE LOCATION ALLOCATION", storage_counts, total=summary["total_items"])
        print(storage_chart)

        # Matplotlib generation prompt
        if prompt_confirm("\nWould you like to generate graphical chart images (PNG) via Matplotlib?", default=False):
            chart_paths = render_matplotlib_charts(self.items, output_dir="exports")
            if chart_paths:
                print(f"{ANSI_GREEN}✔ Generated graphical charts:{ANSI_RESET}")
                for k, p in chart_paths.items():
                    print(f"   - {k}: {p}")
            else:
                print(f"{ANSI_YELLOW}Notice: Matplotlib is not installed in current environment. Using high-fidelity terminal ASCII charts.{ANSI_RESET}")

        input(f"\n{ANSI_DIM}Press [Enter] to return to menu...{ANSI_RESET}")

    # ==========================================
    # Feature 5: Threshold Warnings & Anomalies
    # ==========================================

    def view_threshold_warnings_and_anomalies(self):
        """Audit for overdue deadlines, limit breaches, and data anomalies."""
        print(f"\n{ANSI_BOLD}--- THRESHOLD WARNINGS & ANOMALY DETECTOR ---{ANSI_RESET}")
        warnings = generate_threshold_warnings(self.items)
        anomalies = detect_anomalies(self.items)

        if not warnings and not anomalies:
            print(f"{ANSI_GREEN}✔ Zero threshold warnings or anomalies detected. System running cleanly.{ANSI_RESET}")
        else:
            if warnings:
                print(f"\n{ANSI_BOLD}Active Threshold Alerts ({len(warnings)}):{ANSI_RESET}")
                for w in warnings:
                    print(f"  {w['message']}")
                    for it in w["items"][:5]:
                        print(f"     -> [{it.id}] {it.name} (Exp: {it.expiry_date}, {it.days_remaining()}d)")
                    if len(w["items"]) > 5:
                        print(f"     -> ... and {len(w['items']) - 5} more items.")

            if anomalies:
                print(f"\n{ANSI_RED}⚠️ Data Anomalies Detected ({len(anomalies)}):{ANSI_RESET}")
                for a in anomalies:
                    print(f"  • [{a['type']}] Item {a['item_id']} ('{a['item_name']}'): {a['description']}")

        input(f"\n{ANSI_DIM}Press [Enter] to return to menu...{ANSI_RESET}")

    # ==========================================
    # Feature 6: Multi-Format Reports Export
    # ==========================================

    def export_reports_flow(self):
        """Export inventory and summary reports in multiple standard formats."""
        print(f"\n{ANSI_BOLD}--- MULTI-FORMAT REPORT EXPORT ENGINE ---{ANSI_RESET}")
        print("  [1] Structured Markdown Executive Report (.md)")
        print("  [2] Plain-Text Audit Log / Printable Receipt (.txt)")
        print("  [3] Standardized CSV Spreadsheet Export (.csv)")
        print("  [4] Executive JSON Summary Digest (.json)")
        print("  [5] Export ALL Formats Simultaneously")
        print("  [0] Return to Menu")

        opt = input(f"{ANSI_BOLD}Select export option (0-5): {ANSI_RESET}").strip()

        if opt == "1":
            path = self.exporter.export_markdown_report(self.items)
            print(f"{ANSI_GREEN}✔ Exported Markdown report to: {path}{ANSI_RESET}")
        elif opt == "2":
            path = self.exporter.export_plain_text_audit(self.items)
            print(f"{ANSI_GREEN}✔ Exported Audit Log to: {path}{ANSI_RESET}")
        elif opt == "3":
            path = self.exporter.export_csv(self.items)
            print(f"{ANSI_GREEN}✔ Exported CSV inventory to: {path}{ANSI_RESET}")
        elif opt == "4":
            path = self.exporter.export_json_summary(self.items)
            print(f"{ANSI_GREEN}✔ Exported JSON digest to: {path}{ANSI_RESET}")
        elif opt == "5":
            p1 = self.exporter.export_markdown_report(self.items)
            p2 = self.exporter.export_plain_text_audit(self.items)
            p3 = self.exporter.export_csv(self.items)
            p4 = self.exporter.export_json_summary(self.items)
            print(f"{ANSI_GREEN}✔ Exported all 4 report formats successfully!{ANSI_RESET}")
            print(f"  • Markdown: {p1}\n  • Audit Log: {p2}\n  • CSV: {p3}\n  • JSON: {p4}")

        input(f"\n{ANSI_DIM}Press [Enter] to return to menu...{ANSI_RESET}")

    # ==========================================
    # Feature 7: Bulk Dataset Ingestion
    # ==========================================

    def bulk_import_flow(self):
        """Ingest external or legacy datasets with row-by-row validation."""
        print(f"\n{ANSI_BOLD}--- BULK DATASET INGESTION ENGINE ---{ANSI_RESET}")
        path = prompt_string("Enter path to CSV or JSON file to import", min_len=1, max_len=512, default="data/sample_pantry.csv")

        if not os.path.exists(path):
            print(f"{ANSI_RED}✕ File '{path}' does not exist.{ANSI_RESET}")
            return

        result = self.storage.import_bulk_dataset(path)
        valid_items = result["valid_imported_items"]
        errors = result["error_log"]

        print(f"\n{ANSI_BOLD}Bulk Import Processing Results:{ANSI_RESET}")
        print(f"  • Total rows read:      {result['total_rows_read']}")
        print(f"  • Valid items accepted: {ANSI_GREEN}{len(valid_items)}{ANSI_RESET}")
        print(f"  • Invalid rows skipped: {ANSI_RED}{len(errors)}{ANSI_RESET}")

        if errors:
            print(f"\n{ANSI_YELLOW}Row Validation Error Log:{ANSI_RESET}")
            for err in errors[:10]:
                print(f"  ✕ {err}")
            if len(errors) > 10:
                print(f"  ... and {len(errors) - 10} more errors.")

        if valid_items:
            merge = prompt_confirm(f"Merge {len(valid_items)} valid records into current inventory?", default=True)
            if merge:
                existing_ids = {it.id for it in self.items}
                added_count = 0
                updated_count = 0
                for new_it in valid_items:
                    if new_it.id in existing_ids:
                        # Replace existing
                        self.items = [it if it.id != new_it.id else new_it for it in self.items]
                        updated_count += 1
                    else:
                        self.items.append(new_it)
                        existing_ids.add(new_it.id)
                        added_count += 1

                self._save_data()
                print(f"{ANSI_GREEN}✔ Database updated: {added_count} new items added, {updated_count} items overwritten.{ANSI_RESET}")

        input(f"\n{ANSI_DIM}Press [Enter] to return to menu...{ANSI_RESET}")

    # ==========================================
    # Feature 8: Edit or Delete
    # ==========================================

    def edit_or_delete_flow(self):
        """Modify or remove an existing pantry item."""
        print(f"\n{ANSI_BOLD}--- EDIT OR REMOVE PANTRY ITEM ---{ANSI_RESET}")
        item_id = prompt_string("Enter Item ID to modify or delete", min_len=1, max_len=100)
        matched = [it for it in self.items if it.id.lower() == item_id.lower()]

        if not matched:
            print(f"{ANSI_RED}✕ No item found matching ID '{item_id}'.{ANSI_RESET}")
            return

        item = matched[0]
        print(f"\nFound Item: [{item.id}] {item.name}")
        print(f"Category: {item.category} | Location: {item.storage_location} | Expiry: {item.expiry_date} | Qty: {item.quantity}")

        action = prompt_choice("Select action:", ["Edit Item Details", "Delete Item", "Cancel"])

        if action == "Delete Item":
            if prompt_confirm(f"Are you sure you want to permanently delete '{item.name}'?", default=False):
                self.items = [it for it in self.items if it.id != item.id]
                self._save_data()
                print(f"{ANSI_GREEN}✔ Item '{item.id}' deleted successfully.{ANSI_RESET}")

        elif action == "Edit Item Details":
            print(f"\n{ANSI_DIM}Press [Enter] on any field to keep existing value.{ANSI_RESET}")
            new_name = prompt_string("Item Name", min_len=2, max_len=60, default=item.name)
            new_qty = prompt_float("Quantity", min_val=0.01, default=item.quantity)
            new_exp = prompt_date("Expiry Date", default=item.expiry_date)
            new_cost = prompt_float("Unit Cost ($)", min_val=0.0, default=item.unit_cost)
            new_notes = input(f"Notes [{item.notes}]: ").strip() or item.notes

            item.name = new_name
            item.quantity = new_qty
            item.expiry_date = new_exp
            item.unit_cost = new_cost
            item.notes = new_notes

            self._save_data()
            print(f"{ANSI_GREEN}✔ Item '{item.id}' updated successfully!{ANSI_RESET}")

    # ==========================================
    # Feature 9: Graphical User Interface
    # ==========================================

    def launch_gui(self):
        """Launch desktop GUI using Tkinter."""
        try:
            from src.gui import launch_food_tracker_gui
            print(f"\n{ANSI_CYAN}Launching Tkinter Graphical User Interface...{ANSI_RESET}")
            launch_food_tracker_gui(self.storage)
        except Exception as e:
            print(f"{ANSI_RED}✕ Failed to launch GUI: {str(e)}{ANSI_RESET}")
