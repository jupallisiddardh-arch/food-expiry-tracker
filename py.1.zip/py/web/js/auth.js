/* =============================================
   auth.js — Login & Register page logic
   ============================================= */

// ── Fake user store (localStorage) ────────────
const Auth = (() => {
  const USERS_KEY  = 'fet_users';
  const SESSION_KEY = 'fet_session';

  function getUsers() {
    return JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  }
  function saveUsers(u) { localStorage.setItem(USERS_KEY, JSON.stringify(u)); }

  function register({ firstName, lastName, email, password }) {
    const users = getUsers();
    if (users.find(u => u.email === email)) return { ok: false, msg: 'This email is already registered.' };
    users.push({ id: Date.now(), firstName, lastName, email, password: btoa(password), joined: new Date().toISOString() });
    saveUsers(users);
    return { ok: true };
  }

  function login(email, password, remember) {
    const users = getUsers();
    const user  = users.find(u => u.email === email && atob(u.password) === password);
    if (!user) return { ok: false, msg: 'Invalid email or password. Please try again.' };
    const session = { id: user.id, firstName: user.firstName, lastName: user.lastName, email: user.email };
    if (remember) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    } else {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    }
    return { ok: true, user: session };
  }

  function logout() {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = 'login.html';
  }

  function currentUser() {
    const ls = localStorage.getItem(SESSION_KEY);
    const ss = sessionStorage.getItem(SESSION_KEY);
    return JSON.parse(ls || ss || 'null');
  }

  function requireAuth() {
    if (!currentUser()) window.location.href = 'login.html';
  }

  return { register, login, logout, currentUser, requireAuth };
})();

// ── Password strength meter ───────────────────
function checkStrength(password) {
  let score = 0;
  if (password.length >= 8)             score++;
  if (/[A-Z]/.test(password))           score++;
  if (/[0-9]/.test(password))           score++;
  if (/[^A-Za-z0-9]/.test(password))   score++;
  const levels = [
    { pct: '0%',   color: 'var(--clr-border)', label: '' },
    { pct: '25%',  color: 'var(--clr-danger)', label: 'Weak' },
    { pct: '50%',  color: 'var(--clr-warn)',   label: 'Fair' },
    { pct: '75%',  color: 'var(--clr-accent)',  label: 'Good' },
    { pct: '100%', color: 'var(--clr-primary)', label: 'Strong 💪' },
  ];
  return levels[score];
}

// ── Form validation helpers ───────────────────
function showError(id, msg) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('error');
  const err = el.closest('.form-group')?.querySelector('.form-error');
  if (err) { err.textContent = msg; err.classList.add('visible'); }
}
function clearError(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.remove('error');
  const err = el.closest('.form-group')?.querySelector('.form-error');
  if (err) err.classList.remove('visible');
}
function clearAllErrors() {
  document.querySelectorAll('.form-control').forEach(el => el.classList.remove('error'));
  document.querySelectorAll('.form-error').forEach(el => el.classList.remove('visible'));
}
function validateEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }

// ── LOGIN PAGE ────────────────────────────────
function initLoginPage() {
  const form       = document.getElementById('loginForm');
  const emailEl    = document.getElementById('loginEmail');
  const passEl     = document.getElementById('loginPass');
  const toggleBtn  = document.getElementById('togglePass');
  const submitBtn  = document.getElementById('loginSubmit');
  const rememberEl = document.getElementById('remember');

  if (!form) return;

  // Redirect if already logged in
  if (Auth.currentUser()) { window.location.href = 'dashboard.html'; return; }

  // Toggle password visibility
  toggleBtn?.addEventListener('click', () => {
    const show = passEl.type === 'password';
    passEl.type = show ? 'text' : 'password';
    toggleBtn.textContent = show ? '🙈' : '👁';
  });

  // Live validation
  emailEl?.addEventListener('blur', () => {
    if (!validateEmail(emailEl.value.trim())) showError('loginEmail', 'Please enter a valid email address.');
    else clearError('loginEmail');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAllErrors();
    const email    = emailEl.value.trim();
    const password = passEl.value;
    const remember = rememberEl?.checked || false;
    let valid = true;

    if (!validateEmail(email)) { showError('loginEmail', 'Valid email is required.'); valid = false; }
    if (password.length < 1)   { showError('loginPass',  'Password is required.');    valid = false; }
    if (!valid) return;

    // Show spinner
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span> Signing in…';

    await new Promise(r => setTimeout(r, 900)); // fake async delay

    const result = Auth.login(email, password, remember);
    if (result.ok) {
      Toast.show(`Welcome back, ${result.user.firstName}! 🎉`, 'success');
      setTimeout(() => window.location.href = 'dashboard.html', 800);
    } else {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '🔐 Sign In';
      showError('loginPass', result.msg);
      Toast.show(result.msg, 'error');
    }
  });

  // Google demo btn
  document.getElementById('googleBtn')?.addEventListener('click', () => {
    Toast.show('Google sign-in requires a backend integration.', 'info');
  });
}

// ── REGISTER PAGE ─────────────────────────────
function initRegisterPage() {
  const form      = document.getElementById('registerForm');
  const passEl    = document.getElementById('regPass');
  const confirmEl = document.getElementById('regConfirm');
  const toggleBtn = document.getElementById('togglePass');
  const submitBtn = document.getElementById('regSubmit');
  const fillBar   = document.querySelector('.strength-fill');
  const fillText  = document.querySelector('.strength-text');

  if (!form) return;

  if (Auth.currentUser()) { window.location.href = 'dashboard.html'; return; }

  toggleBtn?.addEventListener('click', () => {
    const show = passEl.type === 'password';
    passEl.type = show ? 'text' : 'password';
    toggleBtn.textContent = show ? '🙈' : '👁';
  });

  passEl?.addEventListener('input', () => {
    const s = checkStrength(passEl.value);
    if (fillBar) { fillBar.style.width = s.pct; fillBar.style.background = s.color; }
    if (fillText) fillText.textContent = s.label;
  });

  document.getElementById('regEmail')?.addEventListener('blur', function() {
    if (!validateEmail(this.value.trim())) showError('regEmail', 'Enter a valid email address.');
    else clearError('regEmail');
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAllErrors();
    const firstName = document.getElementById('regFirst')?.value.trim();
    const lastName  = document.getElementById('regLast')?.value.trim();
    const email     = document.getElementById('regEmail')?.value.trim();
    const password  = passEl.value;
    const confirm   = confirmEl?.value;
    const terms     = document.getElementById('terms')?.checked;
    let valid = true;

    if (!firstName)                { showError('regFirst',   'First name is required.');          valid=false; }
    if (!lastName)                 { showError('regLast',    'Last name is required.');           valid=false; }
    if (!validateEmail(email))     { showError('regEmail',   'Valid email is required.');         valid=false; }
    if (password.length < 8)       { showError('regPass',    'Password must be at least 8 chars.'); valid=false; }
    if (password !== confirm)      { showError('regConfirm', 'Passwords do not match.');          valid=false; }
    if (!terms)                    { Toast.show('Please accept the Terms & Conditions.', 'warning'); valid=false; }
    if (!valid) return;

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span> Creating Account…';

    await new Promise(r => setTimeout(r, 1000));

    const result = Auth.register({ firstName, lastName, email, password });
    if (result.ok) {
      Toast.show('Account created! Redirecting to login…', 'success');
      setTimeout(() => window.location.href = 'login.html', 1200);
    } else {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '🚀 Create Account';
      showError('regEmail', result.msg);
      Toast.show(result.msg, 'error');
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initLoginPage();
  initRegisterPage();
});
