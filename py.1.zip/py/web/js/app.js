/* =============================================
   app.js — Shared utilities across all pages
   ============================================= */

// ── Toast notification system ──────────────────
const Toast = (() => {
  let container = null;
  function ensureContainer() {
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }
  }
  function show(message, type = 'success', duration = 3500) {
    ensureContainer();
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${icons[type] || icons.info}</span><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.animation = 'fadeOut .35s ease forwards';
      toast.addEventListener('animationend', () => toast.remove());
    }, duration);
  }
  return { show };
})();

// ── Scroll-reveal intersection observer ────────
function initReveal() {
  const els = document.querySelectorAll('.reveal, .stagger');
  if (!els.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  els.forEach(el => io.observe(el));
}

// ── Button ripple effect ───────────────────────
function initRipples() {
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const r = document.createElement('span');
      r.className = 'ripple';
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px;`;
      this.appendChild(r);
      r.addEventListener('animationend', () => r.remove());
    });
  });
}

// ── Navbar hamburger ───────────────────────────
function initNav() {
  const hamburger = document.querySelector('.hamburger');
  const navLinks  = document.querySelector('.nav-links');
  if (!hamburger || !navLinks) return;
  hamburger.addEventListener('click', () => {
    navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
    navLinks.style.flexDirection = 'column';
    navLinks.style.position = 'absolute';
    navLinks.style.top = '64px';
    navLinks.style.left = '0';
    navLinks.style.right = '0';
    navLinks.style.background = 'var(--clr-surface)';
    navLinks.style.padding = '1rem 1.5rem';
    navLinks.style.borderBottom = '1px solid var(--clr-border)';
  });
  // Highlight active page
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === path) a.classList.add('active');
  });
}

// ── Animated number counters ──────────────────
function animateCounter(el, target, duration = 1800) {
  const start = performance.now();
  const isFloat = String(target).includes('.');
  function step(ts) {
    const progress = Math.min((ts - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const value = ease * target;
    el.textContent = isFloat ? value.toFixed(1) : Math.floor(value).toLocaleString();
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
function initCounters() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        animateCounter(e.target, parseFloat(e.target.dataset.count));
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => io.observe(c));
}

// ── Modal helper ──────────────────────────────
const Modal = (() => {
  function open(id)  { const m = document.getElementById(id); if(m) m.classList.add('open'); }
  function close(id) { const m = document.getElementById(id); if(m) m.classList.remove('open'); }
  function init() {
    document.querySelectorAll('[data-modal-open]').forEach(btn => {
      btn.addEventListener('click', () => open(btn.dataset.modalOpen));
    });
    document.querySelectorAll('[data-modal-close], .modal-overlay').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target === el || el.hasAttribute('data-modal-close')) {
          const overlay = el.closest('.modal-overlay') || document.getElementById(el.dataset.modalClose);
          if (overlay) overlay.classList.remove('open');
        }
      });
    });
    document.querySelectorAll('.modal').forEach(m => m.addEventListener('click', e => e.stopPropagation()));
  }
  return { open, close, init };
})();

// ── Init on DOM ready ─────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initReveal();
  initRipples();
  initNav();
  initCounters();
  Modal.init();
});
