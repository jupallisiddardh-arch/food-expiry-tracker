/* =============================================
   dashboard.js — Inventory CRUD & analytics
   ============================================= */

const DB_KEY = 'fet_inventory';

// ── Sample seed data ───────────────────────────
const SEED_DATA = [
  { id:'ITEM-001', name:'Greek Yogurt 500g',     category:'Dairy',          location:'Fridge',     qty:1,   unit:'tub',     purchase:'2026-11-01', expiry:'2026-11-10', cost:3.99,  notes:'Low-fat' },
  { id:'ITEM-002', name:'Sliced Roast Beef',     category:'Meat & Poultry', location:'Fridge',     qty:1,   unit:'pack',    purchase:'2026-11-10', expiry:'2026-11-27', cost:6.50,  notes:'' },
  { id:'ITEM-003', name:'Fresh Baby Spinach',    category:'Produce',        location:'Fridge',     qty:1,   unit:'bag',     purchase:'2026-11-15', expiry:'2026-11-28', cost:2.79,  notes:'Organic' },
  { id:'ITEM-004', name:'Sourdough Bread',       category:'Bakery',         location:'Countertop', qty:1,   unit:'loaf',    purchase:'2026-11-14', expiry:'2026-11-26', cost:4.50,  notes:'' },
  { id:'ITEM-005', name:'Whole Milk 2L',         category:'Dairy',          location:'Fridge',     qty:1,   unit:'bottle',  purchase:'2026-11-13', expiry:'2026-11-30', cost:3.29,  notes:'' },
  { id:'ITEM-006', name:'Fresh Strawberries',    category:'Produce',        location:'Fridge',     qty:1,   unit:'punnet',  purchase:'2026-11-15', expiry:'2026-12-01', cost:3.99,  notes:'Local farm' },
  { id:'ITEM-007', name:'Atlantic Salmon Fillet',category:'Seafood',        location:'Fridge',     qty:2,   unit:'fillets', purchase:'2026-11-18', expiry:'2026-12-05', cost:7.50,  notes:'' },
  { id:'ITEM-008', name:'Chicken Breast Fillets',category:'Meat & Poultry', location:'Fridge',     qty:0.8, unit:'kg',      purchase:'2026-11-17', expiry:'2026-12-07', cost:11.00, notes:'Free-range' },
  { id:'ITEM-009', name:'Hass Avocados',         category:'Produce',        location:'Countertop', qty:3,   unit:'units',   purchase:'2026-11-16', expiry:'2026-12-10', cost:1.80,  notes:'' },
  { id:'ITEM-010', name:'Basmati Rice 5kg',      category:'Grains & Pasta', location:'Pantry',     qty:1,   unit:'bag',     purchase:'2026-08-01', expiry:'2027-08-15', cost:16.50, notes:'' },
  { id:'ITEM-011', name:'Natural Peanut Butter', category:'Condiments',     location:'Pantry',     qty:1,   unit:'jar',     purchase:'2026-10-01', expiry:'2027-10-20', cost:5.20,  notes:'' },
  { id:'ITEM-012', name:'Frozen Mixed Berries',  category:'Frozen Foods',   location:'Freezer',    qty:1,   unit:'bag',     purchase:'2026-10-20', expiry:'2027-03-20', cost:6.50,  notes:'Smoothie blend' },
  { id:'ITEM-013', name:'Canned Chickpeas',      category:'Canned Goods',   location:'Pantry',     qty:4,   unit:'cans',    purchase:'2026-08-15', expiry:'2028-02-01', cost:1.30,  notes:'' },
  { id:'ITEM-014', name:'Extra Virgin Olive Oil', category:'Condiments',    location:'Pantry',     qty:1,   unit:'bottle',  purchase:'2026-09-01', expiry:'2027-11-15', cost:14.00, notes:'Cold pressed' },
  { id:'ITEM-015', name:'Canned Diced Tomatoes', category:'Canned Goods',   location:'Pantry',     qty:6,   unit:'cans',    purchase:'2026-08-20', expiry:'2028-03-15', cost:1.20,  notes:'' },
];

// ── Inventory data layer ───────────────────────
const Inventory = (() => {
  function load() {
    const raw = localStorage.getItem(DB_KEY);
    if (!raw) { localStorage.setItem(DB_KEY, JSON.stringify(SEED_DATA)); return SEED_DATA; }
    return JSON.parse(raw);
  }
  function save(items) { localStorage.setItem(DB_KEY, JSON.stringify(items)); }
  function add(item) {
    const items = load();
    if (items.find(i => i.id === item.id)) return { ok:false, msg:'Item ID already exists.' };
    items.push(item);
    save(items);
    return { ok:true };
  }
  function update(id, data) {
    const items = load();
    const idx = items.findIndex(i => i.id === id);
    if (idx < 0) return { ok:false };
    items[idx] = { ...items[idx], ...data };
    save(items);
    return { ok:true };
  }
  function remove(id) {
    const items = load().filter(i => i.id !== id);
    save(items);
  }
  function nextId() {
    const nums = load().map(i => parseInt(i.id.replace('ITEM-',''))).filter(n => !isNaN(n));
    return 'ITEM-' + String(Math.max(0, ...nums) + 1).padStart(3,'0');
  }
  return { load, add, update, remove, nextId };
})();

// ── Shelf-life helpers ─────────────────────────
function daysLeft(expiry) {
  const diff = new Date(expiry) - new Date();
  return Math.ceil(diff / 86400000);
}
function statusOf(expiry) {
  const d = daysLeft(expiry);
  if (d < 0)  return { label:'Expired',       cls:'badge-red',    days: d };
  if (d <= 3) return { label:'Critical',      cls:'badge-red',    days: d };
  if (d <= 7) return { label:'Expiring Soon', cls:'badge-yellow', days: d };
  return             { label:'Fresh',         cls:'badge-green',  days: d };
}

// ── Dashboard state ────────────────────────────
let currentItems = [];
let filteredItems = [];
let sortKey = 'expiry';
let sortAsc = true;
let currentPage = 1;
const PAGE_SIZE = 8;
let editingId = null;

// ── Render ─────────────────────────────────────
function renderMetrics(items) {
  const total = items.length;
  const totalValue = items.reduce((s, i) => s + (i.qty * i.cost), 0);
  const expired  = items.filter(i => daysLeft(i.expiry) < 0).length;
  const critical = items.filter(i => { const d = daysLeft(i.expiry); return d >= 0 && d <= 3; }).length;
  const riskValue = items.filter(i => daysLeft(i.expiry) <= 3).reduce((s,i) => s + (i.qty*i.cost), 0);

  document.getElementById('m-total').textContent   = total;
  document.getElementById('m-value').textContent   = '$' + totalValue.toFixed(2);
  document.getElementById('m-expired').textContent = expired;
  document.getElementById('m-risk').textContent    = '$' + riskValue.toFixed(2);

  // Alerts
  const alertBar = document.getElementById('alertBar');
  if (alertBar) {
    if (expired > 0 || critical > 0) {
      alertBar.style.display = 'flex';
      alertBar.innerHTML = `🚨 <strong>${expired} expired</strong> and <strong>${critical} critical</strong> items need immediate attention — total risk: <strong>$${riskValue.toFixed(2)}</strong>`;
    } else {
      alertBar.style.display = 'none';
    }
  }
}

function renderTable(items, page = 1) {
  const tbody  = document.getElementById('invBody');
  const empty  = document.getElementById('emptyState');
  const pgInfo = document.getElementById('pgInfo');
  if (!tbody) return;

  const start = (page - 1) * PAGE_SIZE;
  const slice = items.slice(start, start + PAGE_SIZE);

  if (!items.length) {
    tbody.innerHTML = '';
    empty.style.display = 'block';
    if (pgInfo) pgInfo.textContent = '0 items';
    renderPagination(0, page);
    return;
  }
  empty.style.display = 'none';
  if (pgInfo) pgInfo.textContent = `${start+1}–${Math.min(start+PAGE_SIZE, items.length)} of ${items.length} items`;

  tbody.innerHTML = slice.map((item, idx) => {
    const st = statusOf(item.expiry);
    const totalCost = (item.qty * item.cost).toFixed(2);
    const delay = idx * 0.04;
    return `
    <tr style="animation-delay:${delay}s" data-id="${item.id}">
      <td><code style="color:var(--clr-accent);font-size:.8rem">${item.id}</code></td>
      <td><strong>${item.name}</strong>${item.notes ? `<br><small style="color:var(--clr-muted)">${item.notes}</small>` : ''}</td>
      <td><span class="badge badge-blue">${item.category}</span></td>
      <td>${item.location}</td>
      <td>${item.qty} ${item.unit}</td>
      <td>${item.expiry}</td>
      <td><span class="badge ${st.cls}">${st.label}</span> <small style="color:var(--clr-muted)">${st.days >= 0 ? st.days+'d' : Math.abs(st.days)+'d ago'}</small></td>
      <td>$${totalCost}</td>
      <td>
        <div class="row-actions">
          <button class="icon-btn" onclick="openEdit('${item.id}')" title="Edit">✏️</button>
          <button class="icon-btn del" onclick="deleteItem('${item.id}')" title="Delete">🗑</button>
        </div>
      </td>
    </tr>`;
  }).join('');

  renderPagination(items.length, page);
}

function renderPagination(total, page) {
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const wrap = document.getElementById('paginationBtns');
  const info = document.getElementById('pgInfo');
  if (!wrap) return;

  let btns = `<button class="page-btn" onclick="goPage(${page-1})" ${page<=1?'disabled':''}>‹</button>`;
  for (let i = 1; i <= totalPages; i++) {
    btns += `<button class="page-btn ${i===page?'active':''}" onclick="goPage(${i})">${i}</button>`;
  }
  btns += `<button class="page-btn" onclick="goPage(${page+1})" ${page>=totalPages?'disabled':''}>›</button>`;
  wrap.innerHTML = btns;
}

function goPage(p) {
  const total = filteredItems.length;
  const max = Math.ceil(total / PAGE_SIZE);
  currentPage = Math.max(1, Math.min(p, max));
  renderTable(filteredItems, currentPage);
}

// ── Filter & sort ──────────────────────────────
function applyFilters() {
  const q    = document.getElementById('searchBox')?.value.toLowerCase() || '';
  const cat  = document.getElementById('filterCat')?.value || 'all';
  const stat = document.getElementById('filterStatus')?.value || 'all';
  const loc  = document.getElementById('filterLoc')?.value || 'all';

  filteredItems = currentItems.filter(item => {
    const matchQ    = !q || item.name.toLowerCase().includes(q) || item.category.toLowerCase().includes(q) || item.id.toLowerCase().includes(q);
    const matchCat  = cat === 'all' || item.category === cat;
    const matchStat = (() => {
      if (stat === 'all') return true;
      const d = daysLeft(item.expiry);
      if (stat === 'expired')  return d < 0;
      if (stat === 'critical') return d >= 0 && d <= 3;
      if (stat === 'soon')     return d > 3 && d <= 7;
      if (stat === 'fresh')    return d > 7;
      return true;
    })();
    const matchLoc = loc === 'all' || item.location === loc;
    return matchQ && matchCat && matchStat && matchLoc;
  });

  // Sort
  filteredItems.sort((a, b) => {
    let va, vb;
    if      (sortKey === 'expiry')   { va = new Date(a.expiry); vb = new Date(b.expiry); }
    else if (sortKey === 'name')     { va = a.name.toLowerCase(); vb = b.name.toLowerCase(); }
    else if (sortKey === 'cost')     { va = a.qty * a.cost; vb = b.qty * b.cost; }
    else if (sortKey === 'qty')      { va = a.qty; vb = b.qty; }
    else if (sortKey === 'category') { va = a.category; vb = b.category; }
    else { va = a[sortKey] || ''; vb = b[sortKey] || ''; }
    if (va < vb) return sortAsc ? -1 : 1;
    if (va > vb) return sortAsc ? 1 : -1;
    return 0;
  });

  currentPage = 1;
  renderTable(filteredItems, 1);
}

function setSort(key) {
  if (sortKey === key) sortAsc = !sortAsc;
  else { sortKey = key; sortAsc = true; }
  applyFilters();
  document.querySelectorAll('.full-table th').forEach(th => {
    th.textContent = th.textContent.replace(/ [▲▼]$/, '');
    if (th.dataset.sort === key) th.textContent += sortAsc ? ' ▲' : ' ▼';
  });
}

// ── CRUD ──────────────────────────────────────
function openAdd() {
  editingId = null;
  document.getElementById('modalTitle').textContent = '➕ Add New Item';
  document.getElementById('itemForm').reset();
  document.getElementById('itemId').value = Inventory.nextId();
  document.getElementById('itemId').readOnly = false;
  document.getElementById('purchaseDate').value = new Date().toISOString().split('T')[0];
  Modal.open('itemModal');
}

function openEdit(id) {
  const item = currentItems.find(i => i.id === id);
  if (!item) return;
  editingId = id;
  document.getElementById('modalTitle').textContent = '✏️ Edit Item';
  document.getElementById('itemId').value       = item.id;
  document.getElementById('itemId').readOnly    = true;
  document.getElementById('itemName').value     = item.name;
  document.getElementById('itemCategory').value = item.category;
  document.getElementById('itemLocation').value = item.location;
  document.getElementById('itemQty').value      = item.qty;
  document.getElementById('itemUnit').value     = item.unit;
  document.getElementById('purchaseDate').value = item.purchase;
  document.getElementById('expiryDate').value   = item.expiry;
  document.getElementById('itemCost').value     = item.cost;
  document.getElementById('itemNotes').value    = item.notes || '';
  Modal.open('itemModal');
}

function deleteItem(id) {
  const item = currentItems.find(i => i.id === id);
  if (!item) return;
  if (!confirm(`Delete "${item.name}"? This cannot be undone.`)) return;
  Inventory.remove(id);
  currentItems = Inventory.load();
  applyFilters();
  renderMetrics(currentItems);
  Toast.show(`"${item.name}" deleted.`, 'warning');
}

function saveItem(e) {
  e.preventDefault();
  const id       = document.getElementById('itemId').value.trim();
  const name     = document.getElementById('itemName').value.trim();
  const category = document.getElementById('itemCategory').value;
  const location = document.getElementById('itemLocation').value;
  const qty      = parseFloat(document.getElementById('itemQty').value);
  const unit     = document.getElementById('itemUnit').value.trim();
  const purchase = document.getElementById('purchaseDate').value;
  const expiry   = document.getElementById('expiryDate').value;
  const cost     = parseFloat(document.getElementById('itemCost').value) || 0;
  const notes    = document.getElementById('itemNotes').value.trim();

  if (!id || !name || !expiry) { Toast.show('ID, Name, and Expiry Date are required.', 'error'); return; }
  if (isNaN(qty) || qty <= 0)  { Toast.show('Quantity must be a positive number.',      'error'); return; }

  const data = { id, name, category, location, qty, unit, purchase, expiry, cost, notes };

  if (editingId) {
    Inventory.update(editingId, data);
    Toast.show(`"${name}" updated!`, 'success');
  } else {
    const r = Inventory.add(data);
    if (!r.ok) { Toast.show(r.msg, 'error'); return; }
    Toast.show(`"${name}" added to pantry!`, 'success');
  }

  Modal.close('itemModal');
  currentItems = Inventory.load();
  applyFilters();
  renderMetrics(currentItems);
}

// ── Logout ─────────────────────────────────────
function doLogout() {
  Auth.logout();
}

// ── Init dashboard ─────────────────────────────
function initDashboard() {
  Auth.requireAuth();

  // Show user info
  const user = Auth.currentUser();
  if (user) {
    const avatarEls = document.querySelectorAll('.user-avatar-sm');
    avatarEls.forEach(el => el.textContent = (user.firstName?.[0] || 'U') + (user.lastName?.[0] || ''));
    document.querySelectorAll('.user-name').forEach(el => el.textContent = user.firstName + ' ' + user.lastName);
    document.querySelectorAll('.user-email').forEach(el => el.textContent = user.email);
    document.querySelectorAll('.greeting-name').forEach(el => el.textContent = user.firstName);
  }

  currentItems = Inventory.load();
  renderMetrics(currentItems);
  applyFilters();

  // Wire search & filters
  document.getElementById('searchBox')?.addEventListener('input', applyFilters);
  document.getElementById('filterCat')?.addEventListener('change', applyFilters);
  document.getElementById('filterStatus')?.addEventListener('change', applyFilters);
  document.getElementById('filterLoc')?.addEventListener('change', applyFilters);

  // Sort headers
  document.querySelectorAll('.full-table th[data-sort]').forEach(th => {
    th.addEventListener('click', () => setSort(th.dataset.sort));
  });

  // Add item form
  document.getElementById('itemForm')?.addEventListener('submit', saveItem);

  // Logout
  document.getElementById('logoutBtn')?.addEventListener('click', doLogout);

  // Greeting
  const hour = new Date().getHours();
  const greet = hour < 12 ? '☀️ Good morning' : hour < 17 ? '👋 Good afternoon' : '🌙 Good evening';
  document.querySelectorAll('.time-greeting').forEach(el => el.textContent = greet);
}

document.addEventListener('DOMContentLoaded', initDashboard);
