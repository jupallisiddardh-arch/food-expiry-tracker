"""Automated end-to-end demo script simulating the hackathon walkthrough."""

import os
import sys

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.models import FoodItem, ExpiryStatus
from src.storage import StorageManager
from src.analytics import generate_executive_summary
from src.visualizer import format_table, render_ascii_bar_chart
from src.exporter import ReportExporter
from src.validation import validate_date_string, validate_food_item_dict

def run_hackathon_demo():
    print("=" * 75)
    print("      FOOD EXPIRY TRACKER - HACKATHON DEMO WALKTHROUGH")
    print("=" * 75)

    storage = StorageManager("data/inventory.json", "data/inventory.csv")
    items, warnings = storage.load_from_json()
    print(f"\n[Step 1] Initialized database: {len(items)} items loaded.")
    if warnings:
        print(f"Warnings: {warnings}")

    print("\n[Step 2] Displaying initial paginated table view (Page 1):")
    table_str, curr_page, total_pages = format_table(items, page=1, page_size=6)
    print(table_str)

    print("\n[Step 3] Demonstrating Defensive Input Validation:")
    test_cases = [
        {"name": "Bad Date Test", "input_date": "not-a-date", "expected": False},
        {"name": "Shortcut +3d Test", "input_date": "+3d", "expected": True},
        {"name": "Negative Qty Test", "dict": {"id": "ERR-1", "name": "Bad", "quantity": -2, "expiry_date": "2026-11-25"}, "expected": False},
        {"name": "Valid Item Test", "dict": {"id": "ITEM-DEMO", "name": "Organic Honeycomb", "category": "Snacks & Sweets", "storage_location": "Pantry", "quantity": 1, "unit": "jar", "expiry_date": "2027-01-01", "unit_cost": 9.50}, "expected": True}
    ]

    for tc in test_cases:
        if "input_date" in tc:
            ok, parsed, err = validate_date_string(tc["input_date"])
            print(f"  • {tc['name']}: Input '{tc['input_date']}' -> Valid: {ok} (Msg: {err or parsed})")
        else:
            ok, cleaned, errs = validate_food_item_dict(tc["dict"])
            print(f"  • {tc['name']}: -> Valid: {ok} (Errors caught: {errs if errs else 'None (Clean)'})")

    print("\n[Step 4] Adding new item 'ITEM-DEMO' and testing persistence:")
    ok, cleaned, _ = validate_food_item_dict(test_cases[3]["dict"])
    new_item = FoodItem.from_dict(cleaned)
    # Remove if existing
    items = [it for it in items if it.id != new_item.id]
    items.append(new_item)
    storage.save_to_json(items)
    storage.save_to_csv(items)

    # Re-read from disk to prove persistence!
    reloaded_items, _ = storage.load_from_json()
    found = any(it.id == "ITEM-DEMO" for it in reloaded_items)
    print(f"  • Saved and reloaded from disk: ITEM-DEMO persisted? {found}")

    print("\n[Step 5] Running Executive Summary & Analytics:")
    summary = generate_executive_summary(reloaded_items)
    print(f"  • Total items: {summary['total_items']}")
    print(f"  • Portfolio Value: ${summary['total_value']:.2f}")
    print(f"  • Total at Risk: ${summary['waste_risk']['at_risk_value']:.2f} ({summary['waste_risk']['risk_percentage']}%)")

    print("\n[Step 6] ASCII Horizontal Bar Charts:")
    chart = render_ascii_bar_chart("STATUS DISTRIBUTION", summary["status_counts"], total=summary["total_items"])
    print(chart)

    print("\n[Step 7] Generating Multi-Format Exports:")
    exporter = ReportExporter("exports")
    p_md = exporter.export_markdown_report(reloaded_items)
    p_txt = exporter.export_plain_text_audit(reloaded_items)
    p_csv = exporter.export_csv(reloaded_items)
    p_json = exporter.export_json_summary(reloaded_items)
    print(f"  • Markdown Report: {p_md}")
    print(f"  • Plain-Text Audit: {p_txt}")
    print(f"  • Standardized CSV: {p_csv}")
    print(f"  • JSON Summary: {p_json}")

    print("\n" + "=" * 75)
    print("✔ DEMO WALKTHROUGH COMPLETED SUCCESSFULLY!")
    print("=" * 75)

if __name__ == "__main__":
    run_hackathon_demo()
