"""Helper script to sync sample pantry data across CSV and JSON."""
import os
import sys

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.storage import StorageManager

def main():
    sm = StorageManager(json_path="data/inventory.json", csv_path="data/inventory.csv")
    res = sm.import_bulk_dataset("data/sample_pantry.csv")
    print(f"Imported from CSV: {len(res['valid_imported_items'])} items, errors: {len(res['error_log'])}")
    if res["error_log"]:
        for e in res["error_log"]:
            print(f"  Error: {e}")

    items = res["valid_imported_items"]
    # Save live files
    sm.save_to_json(items)
    sm.save_to_csv(items)

    # Save sample JSON
    sample_json_sm = StorageManager(json_path="data/sample_pantry.json", csv_path="data/sample_pantry.csv")
    sample_json_sm.save_to_json(items)
    print("Successfully synchronized data/inventory.json, data/inventory.csv, and data/sample_pantry.json!")

if __name__ == "__main__":
    main()
