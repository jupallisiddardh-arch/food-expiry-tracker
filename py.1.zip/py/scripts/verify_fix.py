"""Quick smoke test to verify the get_status_badge fix in cli.py."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.cli import ExpiryTrackerCLI
from src.visualizer import get_status_badge
from src.models import FoodItem
from datetime import date, timedelta

item = FoodItem(
    id='TEST-001', name='Test Banana', category='Produce',
    storage_location='Countertop', quantity=3.0, unit='units',
    purchase_date=date.today().strftime('%Y-%m-%d'),
    expiry_date=(date.today() + timedelta(days=2)).strftime('%Y-%m-%d'),
    unit_cost=0.5
)
badge = get_status_badge(item)
cost = item.total_cost
assert cost == 1.5, f"Expected 1.5, got {cost}"
assert len(badge) > 0
print(f"[PASS] Badge: {badge}")
print(f"[PASS] Total cost: {cost}")
print("[PASS] get_status_badge import fix verified - add_item_interactive will not crash.")
