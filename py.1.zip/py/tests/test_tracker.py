"""Comprehensive automated test suite for Food Expiry Tracker.

Covers:
  - Data models & computed properties
  - Defensive input validation & sanitization
  - Business logic, shelf life, & waste risk calculations
  - Storage persistence, corruption handling, & recovery
  - Multi-criteria search & filtering
  - Analytics & aggregation
  - Report exporters (Markdown, CSV, TXT, JSON)
  - Bulk ingestion with error logging
"""

import os
import shutil
import tempfile
import unittest
from datetime import date, timedelta

from src.models import FoodItem, FoodCategory, StorageLocation, ExpiryStatus
from src.validation import (
    sanitize_string, validate_date_string, validate_food_item_dict
)
from src.business_logic import (
    calculate_days_remaining, get_expiry_status, compute_waste_risk,
    generate_threshold_warnings, detect_anomalies, rank_consumption_priority
)
from src.storage import StorageManager
from src.search_filter import (
    search_by_keyword, filter_by_category, filter_by_storage,
    filter_by_status, filter_by_days_range, sort_items
)
from src.analytics import generate_executive_summary
from src.exporter import ReportExporter


class TestFoodItemModel(unittest.TestCase):
    """Test core data structure and computed properties."""

    def setUp(self):
        self.today = date.today()
        self.item_expired = FoodItem(
            id="T-01",
            name="Milk",
            category=FoodCategory.DAIRY.value,
            storage_location=StorageLocation.FRIDGE.value,
            quantity=2.0,
            unit="liters",
            purchase_date=(self.today - timedelta(days=10)).strftime("%Y-%m-%d"),
            expiry_date=(self.today - timedelta(days=2)).strftime("%Y-%m-%d"),
            unit_cost=3.50
        )
        self.item_critical = FoodItem(
            id="T-02",
            name="Fish",
            category=FoodCategory.SEAFOOD.value,
            storage_location=StorageLocation.FRIDGE.value,
            quantity=1.0,
            unit="pack",
            purchase_date=self.today.strftime("%Y-%m-%d"),
            expiry_date=(self.today + timedelta(days=2)).strftime("%Y-%m-%d"),
            unit_cost=12.00
        )
        self.item_safe = FoodItem(
            id="T-03",
            name="Rice",
            category=FoodCategory.GRAINS_PASTA.value,
            storage_location=StorageLocation.PANTRY.value,
            quantity=5.0,
            unit="kg",
            purchase_date=self.today.strftime("%Y-%m-%d"),
            expiry_date=(self.today + timedelta(days=180)).strftime("%Y-%m-%d"),
            unit_cost=2.00
        )

    def test_computed_days_and_status(self):
        self.assertEqual(self.item_expired.days_remaining(), -2)
        self.assertEqual(self.item_expired.status(), ExpiryStatus.EXPIRED)
        self.assertTrue(self.item_expired.is_expired)

        self.assertEqual(self.item_critical.days_remaining(), 2)
        self.assertEqual(self.item_critical.status(), ExpiryStatus.CRITICAL)
        self.assertTrue(self.item_critical.is_urgent)

        self.assertEqual(self.item_safe.days_remaining(), 180)
        self.assertEqual(self.item_safe.status(), ExpiryStatus.SAFE)
        self.assertFalse(self.item_safe.is_expired)

    def test_total_cost_calculation(self):
        self.assertEqual(self.item_expired.total_cost, 7.00)
        self.assertEqual(self.item_critical.total_cost, 12.00)
        self.assertEqual(self.item_safe.total_cost, 10.00)

    def test_to_dict_and_from_dict(self):
        data = self.item_critical.to_dict()
        self.assertIn("days_remaining", data)
        self.assertIn("status", data)
        self.assertIn("total_cost", data)

        reconstructed = FoodItem.from_dict(data)
        self.assertEqual(reconstructed.id, self.item_critical.id)
        self.assertEqual(reconstructed.name, self.item_critical.name)
        self.assertEqual(reconstructed.quantity, self.item_critical.quantity)


class TestValidation(unittest.TestCase):
    """Test input sanitization and defensive validation checks."""

    def test_sanitize_string(self):
        self.assertEqual(sanitize_string("  hello world \t \n"), "hello world")
        self.assertEqual(sanitize_string(None), "")
        self.assertEqual(sanitize_string("clean\x00data"), "cleandata")

    def test_date_string_validation(self):
        # Valid standard format
        ok, d, err = validate_date_string("2026-12-31")
        self.assertTrue(ok)
        self.assertEqual(d.strftime("%Y-%m-%d"), "2026-12-31")

        # Shortcuts
        today = date.today()
        ok, d, _ = validate_date_string("today")
        self.assertTrue(ok)
        self.assertEqual(d, today)

        ok, d, _ = validate_date_string("+3d")
        self.assertTrue(ok)
        self.assertEqual(d, today + timedelta(days=3))

        ok, d, _ = validate_date_string("+2w")
        self.assertTrue(ok)
        self.assertEqual(d, today + timedelta(weeks=2))

        # Invalid formats
        ok, _, err = validate_date_string("invalid-date")
        self.assertFalse(ok)
        self.assertIn("Invalid date format", err)

        ok, _, err = validate_date_string("1800-01-01")
        self.assertFalse(ok)
        self.assertIn("out of reasonable range", err)

    def test_food_item_dict_validation(self):
        # Valid dictionary
        valid_dict = {
            "id": "ITEM-100",
            "name": "Apples",
            "category": "Produce",
            "storage_location": "Fridge",
            "quantity": 3.5,
            "unit": "kg",
            "purchase_date": "2026-11-01",
            "expiry_date": "2026-11-25",
            "unit_cost": 2.50
        }
        ok, cleaned, errors = validate_food_item_dict(valid_dict)
        self.assertTrue(ok)
        self.assertEqual(len(errors), 0)
        self.assertEqual(cleaned["name"], "Apples")
        self.assertEqual(cleaned["quantity"], 3.5)

        # Invalid dictionary (negative qty, invalid date, empty name)
        invalid_dict = {
            "id": "",
            "name": "A",
            "quantity": -5,
            "expiry_date": "bad-date",
            "unit_cost": -10
        }
        ok, cleaned, errors = validate_food_item_dict(invalid_dict)
        self.assertFalse(ok)
        self.assertTrue(any("ID is required" in e for e in errors))
        self.assertTrue(any("at least 2 characters" in e for e in errors))
        self.assertTrue(any("greater than zero" in e for e in errors))
        self.assertTrue(any("Expiry date error" in e for e in errors))
        self.assertTrue(any("cannot be negative" in e for e in errors))


class TestBusinessLogic(unittest.TestCase):
    """Test computational rules, waste risk valuation, and anomaly checks."""

    def setUp(self):
        self.today = date.today()
        self.items = [
            FoodItem("1", "Expired Item", "Dairy", "Fridge", 1.0, "unit", "2026-11-01", (self.today - timedelta(days=3)).strftime("%Y-%m-%d"), 10.0),
            FoodItem("2", "Critical Item", "Meat & Poultry", "Fridge", 2.0, "units", "2026-11-01", (self.today + timedelta(days=1)).strftime("%Y-%m-%d"), 15.0),
            FoodItem("3", "Safe Item", "Grains & Pasta", "Pantry", 1.0, "unit", "2026-11-01", (self.today + timedelta(days=30)).strftime("%Y-%m-%d"), 5.0),
        ]

    def test_calculate_days_and_status(self):
        self.assertEqual(calculate_days_remaining((self.today + timedelta(days=5)).strftime("%Y-%m-%d")), 5)
        self.assertEqual(get_expiry_status(-1), ExpiryStatus.EXPIRED)
        self.assertEqual(get_expiry_status(0), ExpiryStatus.CRITICAL)
        self.assertEqual(get_expiry_status(3), ExpiryStatus.CRITICAL)
        self.assertEqual(get_expiry_status(7), ExpiryStatus.EXPIRING_SOON)
        self.assertEqual(get_expiry_status(8), ExpiryStatus.SAFE)

    def test_waste_risk_computation(self):
        risk = compute_waste_risk(self.items)
        self.assertEqual(risk["expired_count"], 1)
        self.assertEqual(risk["expired_cost"], 10.0)
        self.assertEqual(risk["critical_count"], 1)
        self.assertEqual(risk["critical_cost"], 30.0)
        self.assertEqual(risk["total_at_risk_cost"], 40.0)
        self.assertEqual(risk["total_inventory_cost"], 45.0)

    def test_threshold_warnings(self):
        warnings = generate_threshold_warnings(self.items)
        self.assertTrue(any(w["code"] == "OVERDUE_EXPIRED" for w in warnings))
        self.assertTrue(any(w["code"] == "EXPIRING_URGENT" for w in warnings))

    def test_anomaly_detection(self):
        bad_items = [
            FoodItem("A1", "Future Purchase", "Dairy", "Fridge", 1, "u", "2026-12-01", "2026-11-01", 5.0),
            FoodItem("A2", "Expensive Caviar", "Seafood", "Fridge", 1, "u", "2026-11-01", "2026-11-15", 999.0),
        ]
        anomalies = detect_anomalies(bad_items)
        self.assertTrue(any(a["type"] == "DATE_INCONSISTENCY" for a in anomalies))
        self.assertTrue(any(a["type"] == "HIGH_UNIT_COST" for a in anomalies))

    def test_priority_ranking(self):
        ranked = rank_consumption_priority(self.items)
        self.assertEqual(ranked[0].id, "1")  # Expired first
        self.assertEqual(ranked[1].id, "2")  # Critical next
        self.assertEqual(ranked[2].id, "3")  # Safe last


class TestStorageManager(unittest.TestCase):
    """Test persistence, corruption recovery, and bulk dataset ingestion."""

    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.json_file = os.path.join(self.temp_dir, "test_inv.json")
        self.csv_file = os.path.join(self.temp_dir, "test_inv.csv")
        self.storage = StorageManager(json_path=self.json_file, csv_path=self.csv_file)

        self.sample_items = [
            FoodItem("ID-1", "Apples", "Produce", "Fridge", 2.0, "kg", "2026-11-01", "2026-11-25", 3.0),
            FoodItem("ID-2", "Bread", "Bakery", "Countertop", 1.0, "loaf", "2026-11-10", "2026-11-15", 4.0),
        ]

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_json_roundtrip(self):
        self.storage.save_to_json(self.sample_items)
        self.assertTrue(os.path.exists(self.json_file))

        loaded, warnings = self.storage.load_from_json()
        self.assertEqual(len(loaded), 2)
        self.assertEqual(loaded[0].name, "Apples")
        self.assertEqual(loaded[1].total_cost, 4.0)

    def test_csv_roundtrip(self):
        self.storage.save_to_csv(self.sample_items)
        self.assertTrue(os.path.exists(self.csv_file))

        loaded, warnings = self.storage.load_from_csv()
        self.assertEqual(len(loaded), 2)
        self.assertEqual(loaded[0].name, "Apples")
        self.assertEqual(loaded[1].name, "Bread")

    def test_missing_file_recovery(self):
        missing_storage = StorageManager(
            json_path=os.path.join(self.temp_dir, "missing.json"),
            csv_path=os.path.join(self.temp_dir, "missing.csv")
        )
        loaded, warnings = missing_storage.load_from_json()
        self.assertEqual(loaded, [])
        self.assertTrue(any("not found" in w for w in warnings))
        self.assertTrue(os.path.exists(missing_storage.json_path))

    def test_corrupted_json_recovery(self):
        # Write corrupted invalid JSON
        with open(self.json_file, "w", encoding="utf-8") as f:
            f.write("<<<CORRUPT NON-JSON DATA>>>")

        loaded, warnings = self.storage.load_from_json()
        self.assertEqual(loaded, [])
        self.assertTrue(any("Corrupted JSON detected" in w for w in warnings))
        # Verify a .bak file was created
        files_in_dir = os.listdir(self.temp_dir)
        self.assertTrue(any(f.endswith(".bak") for f in files_in_dir))

    def test_bulk_dataset_import_with_errors(self):
        # Create a CSV with 1 valid row and 1 invalid row
        test_import_csv = os.path.join(self.temp_dir, "import_test.csv")
        with open(test_import_csv, "w", encoding="utf-8") as f:
            f.write("id,name,category,storage_location,quantity,unit,purchase_date,expiry_date,unit_cost,notes,added_at\n")
            f.write("V-1,Valid Item,Dairy,Fridge,1,bottle,2026-11-01,2026-11-30,2.5,Good,2026-11-01T00:00:00\n")
            f.write("INV-1,,Dairy,Fridge,-5,bottle,bad-date,bad-date,-10,Bad,2026-11-01T00:00:00\n")

        res = self.storage.import_bulk_dataset(test_import_csv)
        self.assertTrue(res["success"])
        self.assertEqual(res["total_rows_read"], 2)
        self.assertEqual(len(res["valid_imported_items"]), 1)
        self.assertEqual(res["valid_imported_items"][0].id, "V-1")
        self.assertEqual(len(res["error_log"]), 1)
        self.assertIn("Row 3", res["error_log"][0])


class TestSearchAndFilter(unittest.TestCase):
    """Test multi-criteria filtering and querying."""

    def setUp(self):
        self.today = date.today()
        self.items = [
            FoodItem("1", "Almond Milk", "Beverages", "Fridge", 1.0, "bottle", "2026-11-01", (self.today + timedelta(days=2)).strftime("%Y-%m-%d"), 3.0),
            FoodItem("2", "Cheddar Cheese", "Dairy", "Fridge", 1.0, "block", "2026-11-01", (self.today + timedelta(days=10)).strftime("%Y-%m-%d"), 5.0),
            FoodItem("3", "Basmati Rice", "Grains & Pasta", "Pantry", 5.0, "kg", "2026-11-01", (self.today + timedelta(days=100)).strftime("%Y-%m-%d"), 15.0),
            FoodItem("4", "Old Bread", "Bakery", "Countertop", 1.0, "loaf", "2026-11-01", (self.today - timedelta(days=1)).strftime("%Y-%m-%d"), 2.0),
        ]

    def test_search_by_keyword(self):
        res = search_by_keyword(self.items, "milk")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].id, "1")

        res = search_by_keyword(self.items, "rice")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].id, "3")

    def test_filter_by_category(self):
        res = filter_by_category(self.items, "Dairy")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].name, "Cheddar Cheese")

    def test_filter_by_storage(self):
        res = filter_by_storage(self.items, "Fridge")
        self.assertEqual(len(res), 2)

    def test_filter_by_status(self):
        res = filter_by_status(self.items, ExpiryStatus.EXPIRED)
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].name, "Old Bread")

    def test_sorting(self):
        by_cost_desc = sort_items(self.items, sort_by="cost", ascending=False)
        self.assertEqual(by_cost_desc[0].name, "Basmati Rice")  # $15

        by_expiry = sort_items(self.items, sort_by="expiry", ascending=True)
        self.assertEqual(by_expiry[0].name, "Old Bread")  # Expired first


class TestAnalyticsAndReports(unittest.TestCase):
    """Test executive summary computation and report generators."""

    def setUp(self):
        self.today = date.today()
        self.temp_dir = tempfile.mkdtemp()
        self.exporter = ReportExporter(output_dir=self.temp_dir)
        self.items = [
            FoodItem("1", "Milk", "Dairy", "Fridge", 1.0, "carton", "2026-11-01", (self.today - timedelta(days=1)).strftime("%Y-%m-%d"), 3.0),
            FoodItem("2", "Fish", "Seafood", "Fridge", 1.0, "pack", "2026-11-01", (self.today + timedelta(days=1)).strftime("%Y-%m-%d"), 10.0),
            FoodItem("3", "Pasta", "Grains & Pasta", "Pantry", 2.0, "packs", "2026-11-01", (self.today + timedelta(days=60)).strftime("%Y-%m-%d"), 2.0),
        ]

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_summary_metrics(self):
        summary = generate_executive_summary(self.items)
        self.assertEqual(summary["total_items"], 3)
        self.assertEqual(summary["total_quantity"], 4.0)
        self.assertEqual(summary["total_value"], 17.0)  # 3 + 10 + 4
        self.assertEqual(summary["waste_risk"]["expired_count"], 1)
        self.assertEqual(summary["waste_risk"]["critical_count"], 1)
        self.assertIn("Dairy", summary["category_breakdown"])

    def test_exports_generation(self):
        # Markdown report
        md_path = self.exporter.export_markdown_report(self.items, "test_report.md")
        self.assertTrue(os.path.exists(md_path))
        with open(md_path, "r", encoding="utf-8") as f:
            md_content = f.read()
        self.assertIn("Executive Summary Report", md_content)
        self.assertIn("Milk", md_content)

        # Plain-text audit
        txt_path = self.exporter.export_plain_text_audit(self.items, "test_audit.txt")
        self.assertTrue(os.path.exists(txt_path))
        with open(txt_path, "r", encoding="utf-8") as f:
            txt_content = f.read()
        self.assertIn("INVENTORY AUDIT LOG", txt_content)

        # Standard CSV
        csv_path = self.exporter.export_csv(self.items, "test_export.csv")
        self.assertTrue(os.path.exists(csv_path))

        # JSON summary
        json_path = self.exporter.export_json_summary(self.items, "test_summary.json")
        self.assertTrue(os.path.exists(json_path))


if __name__ == "__main__":
    unittest.main()
